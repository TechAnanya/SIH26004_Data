"""
Minimal standalone test script for the G5 model: load -> predict -> Grad-CAM.

Run this on its own, separately from the Streamlit app, to confirm the
model file loads correctly and produces sane predictions + a Grad-CAM
overlay on one image, before wiring it back into the full screening app.

Usage:
    python test_model.py path/to/xray.png
    python test_model.py path/to/xray.png --model final_model.h5

Requires: tensorflow, tf-keras, numpy, opencv-python, pillow
    pip install tensorflow tf-keras numpy opencv-python pillow
"""

import os
import sys
import argparse

# MUST be set before the first `import tensorflow` -- forces TensorFlow
# to use its bundled legacy Keras 2 engine, which is what the model was
# actually saved with (TF 2.15). Without this, loading final_model.h5
# fails with either a DepthwiseConv2D 'groups' error or an "Invalid
# Functional model configuration ... loops or disconnected nodes" error,
# because Keras 3 (the current default) serializes/reconstructs the
# Functional graph differently than Keras 2 did.
os.environ.setdefault("TF_USE_LEGACY_KERAS", "1")

import numpy as np
import cv2
from PIL import Image

CLASS_NAMES = ["Normal", "Osteoarthritis"]   # matches train_ds_raw.class_names order
POSITIVE_CLASS_INDEX = 1                      # "Osteoarthritis"
IMG_SIZE = (224, 224)
BASE_LAYER_NAME = "efficientnetb0"            # nested backbone layer name
CONV_LAYER_SUBSTRING = "top_conv"             # target Grad-CAM layer


def load_model(model_path: str):
    import tensorflow as tf

    try:
        model = tf.keras.models.load_model(model_path, compile=False)
    except (TypeError, ValueError) as exc:
        if "DepthwiseConv2D" in str(exc) and "groups" in str(exc):
            # Fallback patch in case the legacy engine still hits this
            # (shouldn't happen with TF_USE_LEGACY_KERAS=1, but kept as
            # a safety net).
            class _CompatDepthwiseConv2D(tf.keras.layers.DepthwiseConv2D):
                def __init__(self, *args, **kwargs):
                    kwargs.pop("groups", None)
                    super().__init__(*args, **kwargs)

            model = tf.keras.models.load_model(
                model_path, compile=False,
                custom_objects={"DepthwiseConv2D": _CompatDepthwiseConv2D},
            )
        else:
            raise
    return model


def load_and_prepare_image(path: str):
    """Raw 0-255 float array -- matches the notebook's preprocess_input,
    which is an identity function for Keras's EfficientNet."""
    img = Image.open(path).convert("RGB").resize(IMG_SIZE, Image.BILINEAR)
    arr = np.array(img, dtype=np.uint8)               # (H, W, 3) for display
    batched = np.expand_dims(arr.astype(np.float32), axis=0)  # (1, H, W, 3)
    return arr, batched


def predict(model, batched_input):
    preds = model.predict(batched_input, verbose=0)[0]   # softmax probs, shape (2,)
    pred_idx = int(np.argmax(preds))
    return pred_idx, preds


def get_grad_cam(model, batched_input, target_class_idx: int):
    import tensorflow as tf

    base_model_inner = model.get_layer(BASE_LAYER_NAME)
    conv_layer_name = [l.name for l in base_model_inner.layers if CONV_LAYER_SUBSTRING in l.name][-1]

    grad_model = tf.keras.models.Model(
        base_model_inner.inputs,
        [base_model_inner.get_layer(conv_layer_name).output, base_model_inner.output],
    )

    base_idx = model.layers.index(base_model_inner)
    head_layers = model.layers[base_idx + 1:]

    tf_input = tf.convert_to_tensor(batched_input, dtype=tf.float32)

    with tf.GradientTape() as tape:
        conv_outputs, base_output = grad_model(tf_input)
        x = base_output
        for layer in head_layers:
            x = layer(x)
        loss = x[:, target_class_idx]

    grads = tape.gradient(loss, conv_outputs)
    pooled_grads = tf.reduce_mean(grads, axis=(0, 1, 2))
    conv_outputs = conv_outputs[0]
    heatmap = conv_outputs @ pooled_grads[..., tf.newaxis]
    heatmap = tf.squeeze(heatmap)
    heatmap = tf.maximum(heatmap, 0) / (tf.math.reduce_max(heatmap) + 1e-8)
    return heatmap.numpy()


def overlay_heatmap(orig_rgb: np.ndarray, heatmap: np.ndarray) -> np.ndarray:
    h, w = orig_rgb.shape[:2]
    heatmap_resized = cv2.resize(heatmap, (w, h))
    heatmap_uint8 = np.uint8(255 * heatmap_resized)
    heatmap_color = cv2.applyColorMap(heatmap_uint8, cv2.COLORMAP_JET)
    heatmap_color = cv2.cvtColor(heatmap_color, cv2.COLOR_BGR2RGB)
    overlay = cv2.addWeighted(orig_rgb, 0.6, heatmap_color, 0.4, 0)
    return overlay


def main():
    parser = argparse.ArgumentParser(description="Test the G5 model: predict + Grad-CAM on one image.")
    parser.add_argument("image", help="Path to a knee X-ray image (jpg/jpeg/png)")
    parser.add_argument("--model", default="final_model.h5", help="Path to the .h5 model file")
    parser.add_argument("--out", default="gradcam_output.png", help="Where to save the Grad-CAM overlay")
    args = parser.parse_args()

    if not os.path.exists(args.image):
        print(f"ERROR: image not found: {args.image}")
        sys.exit(1)
    if not os.path.exists(args.model):
        print(f"ERROR: model not found: {args.model}")
        sys.exit(1)

    print(f"Loading model from {args.model} ...")
    model = load_model(args.model)
    print("Model loaded successfully.")
    print(model.summary())

    print(f"\nLoading and preprocessing image: {args.image}")
    orig_rgb, batched = load_and_prepare_image(args.image)

    print("\nRunning prediction...")
    pred_idx, probs = predict(model, batched)
    pred_label = CLASS_NAMES[pred_idx]
    pred_confidence = float(probs[pred_idx])
    oa_probability = float(probs[POSITIVE_CLASS_INDEX])

    print(f"\n{'='*50}")
    print(f"Predicted class : {pred_label}")
    print(f"Confidence      : {pred_confidence:.2%}")
    print(f"OA probability  : {oa_probability:.2%}")
    print(f"Assessment      : {'ABNORMAL' if oa_probability >= 0.5 else 'NORMAL'}")
    print(f"{'='*50}\n")

    print("Generating Grad-CAM...")
    heatmap = get_grad_cam(model, batched, pred_idx)
    overlay = overlay_heatmap(orig_rgb, heatmap)

    # Save original + Grad-CAM side by side
    side_by_side = np.hstack([orig_rgb, overlay])
    Image.fromarray(side_by_side).save(args.out)
    print(f"Saved original + Grad-CAM overlay to: {args.out}")


if __name__ == "__main__":
    main()
