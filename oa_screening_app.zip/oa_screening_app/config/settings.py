"""
Global application settings.

Keep environment / deployment specific configuration here so the rest of
the codebase never has to hard-code paths, filenames or feature flags.
"""

import os

# ----------------------------------------------------------------------
# Paths
# ----------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

ASSETS_DIR = os.path.join(BASE_DIR, "assets")
TEMP_DIR = os.path.join(ASSETS_DIR, "temp")
REPORTS_DIR = os.path.join(BASE_DIR, "reports")
MODELS_DIR = os.path.join(BASE_DIR, "models")

for _d in (ASSETS_DIR, TEMP_DIR, REPORTS_DIR, MODELS_DIR):
    os.makedirs(_d, exist_ok=True)

# ----------------------------------------------------------------------
# G5 deep-learning model configuration
# ----------------------------------------------------------------------
# Point this at the trained G5 model file once it is supplied. Supported
# out of the box: PyTorch (.pt / .pth) and TensorFlow/Keras (.h5 / .keras
# / a SavedModel directory). The loader in utils/model_loader.py inspects
# the extension and picks the right backend automatically, but you can
# force a backend below if auto-detection ever picks the wrong one.
#
# The values below are pre-filled to match the EfficientNetB0-based Keras
# model described in the supplied training notebook (model.save(...) ->
# final_model.h5). Drop that .h5 file into the models/ folder (or point
# G5_MODEL_PATH at wherever you keep it) and everything else here already
# matches its architecture.
G5_MODEL_PATH = os.environ.get("G5_MODEL_PATH", os.path.join(MODELS_DIR, "final_model.h5"))

# "auto" | "pytorch" | "tensorflow"
G5_MODEL_BACKEND = os.environ.get("G5_MODEL_BACKEND", "auto")

# Input size the model was trained on (width, height). Matches the
# notebook's HYPERPARAMS["image_size"] = (224, 224).
G5_INPUT_SIZE = (224, 224)

# Preprocessing mode applied to the resized 0-255 image before it is fed
# to the model. Must match how the model was trained:
#   "none"              -- raw 0-255 float pixels, no scaling at all.
#                          This is what the notebook uses: Keras's
#                          EfficientNet preprocess_input() is an identity
#                          function (normalization is baked into the
#                          model itself), so this is the correct setting
#                          for the supplied G5 model.
#   "rescale_0_1"        -- divide by 255 only.
#   "imagenet_normalize" -- divide by 255 then subtract/divide by
#                          ImageNet mean/std (G5_NORMALIZE_MEAN/STD below).
#                          Only relevant for a PyTorch G5 model trained
#                          with that convention.
G5_PREPROCESS_MODE = os.environ.get("G5_PREPROCESS_MODE", "none")

G5_NORMALIZE_MEAN = (0.485, 0.456, 0.406)
G5_NORMALIZE_STD = (0.229, 0.224, 0.225)

# Class labels as produced by the G5 model's output layer, in the exact
# order the model was trained with. Matches the notebook's
# train_ds_raw.class_names == ['Normal', 'Osteoarthritis'] (index 0 =
# Normal, index 1 = Osteoarthritis). Update only if you retrain with a
# different class order.
G5_CLASS_LABELS = os.environ.get(
    "G5_CLASS_LABELS", "Normal,Osteoarthritis"
).split(",")

# Index of the label that should be treated as the "positive" / abnormal
# finding when only a single probability is displayed. Matches
# 'Osteoarthritis' at index 1 in G5_CLASS_LABELS above.
G5_POSITIVE_CLASS_INDEX = int(os.environ.get("G5_POSITIVE_CLASS_INDEX", "1"))

# ----------------------------------------------------------------------
# Grad-CAM configuration
# ----------------------------------------------------------------------
# The supplied model wraps its EfficientNetB0 backbone as a NESTED
# sub-model (a layer named "efficientnetb0" inside the outer model), with
# the classification head (GlobalAveragePooling2D -> Dropout -> Dense)
# applied afterwards. Grad-CAM therefore has to reach inside that nested
# sub-model to find the target convolutional layer, then manually replay
# the head layers -- utils/gradcam.py implements exactly this, mirroring
# the training notebook's get_grad_cam() function.
#
# Leave G5_GRADCAM_BASE_LAYER_NAME empty if your model is NOT built this
# way (a plain, non-nested Keras model) -- Grad-CAM will then look for
# G5_GRADCAM_TARGET_LAYER directly on the top-level model instead.
G5_GRADCAM_BASE_LAYER_NAME = os.environ.get("G5_GRADCAM_BASE_LAYER_NAME", "efficientnetb0")

# Name (or substring) of the final convolutional layer to target for
# Grad-CAM, searched for within G5_GRADCAM_BASE_LAYER_NAME's own layers
# (or on the top-level model if that's empty). "top_conv" is
# EfficientNetB0's final conv layer name in Keras applications. Also used
# as the Score-CAM target layer (utils/scorecam.py).
G5_GRADCAM_TARGET_LAYER = os.environ.get("G5_GRADCAM_TARGET_LAYER", "top_conv")

# Percentile (0-100) used to threshold the Grad-CAM heatmap when drawing
# bounding boxes around "high-activation regions" for display.
G5_HIGH_ACTIVATION_PERCENTILE = float(os.environ.get("G5_HIGH_ACTIVATION_PERCENTILE", "85"))

# ----------------------------------------------------------------------
# Score-CAM configuration
# ----------------------------------------------------------------------
# Number of the backbone's strongest activation channels to use when
# building the Score-CAM heatmap. Score-CAM re-runs the full model once
# per selected channel (no GPU assumed), so this trades detail for
# speed: 32 = faster, 64 = more detailed, 128 = slower.
G5_SCORECAM_MAX_CHANNELS = int(os.environ.get("G5_SCORECAM_MAX_CHANNELS", "64"))

# ----------------------------------------------------------------------
# LIME configuration
# ----------------------------------------------------------------------
# Number of perturbed samples LIME generates per explanation. Higher =
# more stable/accurate boundaries but slower. 200-300 is a practical
# CPU-only setting; 500-1000 is more detailed but much slower.
G5_LIME_NUM_SAMPLES = int(os.environ.get("G5_LIME_NUM_SAMPLES", "300"))

# Number of superpixel "features" (regions) highlighted in the LIME mask.
G5_LIME_NUM_FEATURES = int(os.environ.get("G5_LIME_NUM_FEATURES", "10"))

# ----------------------------------------------------------------------
# AI Posture Detection configuration
# ----------------------------------------------------------------------
# Uploaded lower-limb photos are downscaled (preserving aspect ratio) to
# at most this many pixels on the longest side before MediaPipe runs and
# before the annotated overlay is generated. This keeps the in-app
# preview and the PDF report's embedded image a reasonable, fast-loading
# size even when a phone camera photo is several thousand pixels wide --
# it does not change the analysis result, since the HKA angle is a ratio
# of landmark positions, not an absolute-pixel measurement.
POSTURE_MAX_IMAGE_DIMENSION = int(os.environ.get("POSTURE_MAX_IMAGE_DIMENSION", "900"))

# Display width (pixels) of the annotated posture image in the app.
POSTURE_DISPLAY_WIDTH = int(os.environ.get("POSTURE_DISPLAY_WIDTH", "420"))

# ----------------------------------------------------------------------
# Upload constraints
# ----------------------------------------------------------------------
ALLOWED_IMAGE_EXTENSIONS = ("jpg", "jpeg", "png")
MAX_UPLOAD_SIZE_MB = 15

# ----------------------------------------------------------------------
# Misc
# ----------------------------------------------------------------------
APP_NAME = "SandhiSetu"
APP_TAGLINE = "Integrated AI Platform for Knee Osteoarthritis Screening"
ORG_NAME = os.environ.get("OA_SCREEN_ORG_NAME", "Community Health Screening Program")

# ----------------------------------------------------------------------
# Smart India Hackathon (SIH) branding
# ----------------------------------------------------------------------
# Shown in the top bar and on the Dashboard's Problem Statement card.
# Update via environment variables (or directly here) if any of these
# details change.
TEAM_NAME = os.environ.get("OA_SCREEN_TEAM_NAME", "Apex")
SIH_PS_NUMBER = os.environ.get("OA_SCREEN_SIH_PS_NUMBER", "SIH26004")
SIH_PS_TITLE = os.environ.get(
    "OA_SCREEN_SIH_PS_TITLE",
    "AI-Assisted Early Detection System for Osteoarthritis (OA) Risk Markers "
    "in North Eastern Region (NER)",
)
SIH_PS_ORGANIZATION = os.environ.get(
    "OA_SCREEN_SIH_PS_ORG", "Ministry of Development of North Eastern Region (MDoNER)"
)
SIH_PS_CATEGORY = os.environ.get("OA_SCREEN_SIH_PS_CATEGORY", "Hardware")
SIH_PS_THEME = os.environ.get("OA_SCREEN_SIH_PS_THEME", "MedTech / BioTech / HealthTech")

MEDICAL_DISCLAIMER = (
    "This report is generated by an AI-assisted / rule-based preliminary "
    "osteoarthritis (OA) screening system. It is intended to support, not "
    "replace, clinical judgement. Results are NOT a confirmed medical "
    "diagnosis. All findings must be reviewed and interpreted by a "
    "qualified healthcare professional before any clinical decision is made."
)
