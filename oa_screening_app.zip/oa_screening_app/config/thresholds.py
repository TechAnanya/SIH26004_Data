"""
Configurable, evidence-updatable thresholds for the Hardware OA Risk
Marker rule/threshold engine.

IMPORTANT: Nothing in this file is a trained model or a machine-learning
classifier. Every value below is a plain configurable reference number
that a clinician/researcher can revise as better validated evidence
becomes available. The engine in utils/hardware_risk_engine.py only
consumes these constants -- it contains no ML code.

Update these values (and cite the source in the comments) whenever a
better-validated reference range is available for your target population.
"""

# ----------------------------------------------------------------------
# BMI categories (WHO general adult classification; adjust for local
# population-specific guidance if required, e.g. Asian BMI cut-offs)
# ----------------------------------------------------------------------
BMI_THRESHOLDS = {
    "underweight_max": 18.5,
    "normal_max": 24.9,
    "overweight_max": 29.9,
    # >= overweight_max is Obese
}
BMI_OA_RISK_CUTOFF = 25.0  # BMI at/above this is counted as an OA risk factor

# ----------------------------------------------------------------------
# Patient history / symptom scoring
# ----------------------------------------------------------------------
KNEE_PAIN_SCORE_MODERATE = 4   # 0-10 scale; >= this is "moderate" pain
KNEE_PAIN_SCORE_SEVERE = 7     # >= this is "severe" pain

# ----------------------------------------------------------------------
# Sensor-derived measurement thresholds
# ----------------------------------------------------------------------
# Knee Range of Motion (ROM), in degrees. Healthy adult active knee
# flexion is commonly cited around 130-140 degrees; values noticeably
# below the normal reference range are treated as a risk marker for
# reduced/restricted joint mobility associated with OA.
KNEE_ROM_THRESHOLDS = {
    "normal_min_degrees": 120.0,     # >= this: normal
    "borderline_min_degrees": 100.0, # 100-120: borderline restriction
    # < borderline_min_degrees: abnormal / significantly restricted
}

# Walking cadence, in steps per minute. Typical healthy adult walking
# cadence is roughly 100-120 steps/min; reduced cadence can reflect an
# antalgic (pain-avoidant) gait pattern.
WALKING_CADENCE_THRESHOLDS = {
    "normal_min_spm": 90.0,
    "borderline_min_spm": 75.0,
    # < borderline_min_spm: abnormal / markedly reduced cadence
}

# Gait asymmetry index, expressed as a percentage difference between the
# two limbs' gait cycle parameters (0% = perfectly symmetric gait).
GAIT_ASYMMETRY_THRESHOLDS = {
    "normal_max_percent": 5.0,
    "borderline_max_percent": 10.0,
    # > borderline_max_percent: abnormal / significant asymmetry
}

# Left-right plantar/load pressure asymmetry, expressed as a percentage
# difference in load-bearing between limbs.
PRESSURE_ASYMMETRY_THRESHOLDS = {
    "normal_max_percent": 10.0,
    "borderline_max_percent": 20.0,
    # > borderline_max_percent: abnormal / significant load imbalance
}

# ----------------------------------------------------------------------
# Rule-based scoring weights
# ----------------------------------------------------------------------
# Each contributing factor adds points toward the final Hardware OA Risk
# Score when it crosses "borderline" (partial weight) or "abnormal" /
# positive (full weight) thresholds. This is a transparent, additive
# rule-based score -- NOT a statistically calibrated probability. It is
# always reported to the user as a "Screening Category", never as a
# clinical probability, unless a validated scoring formula is supplied
# and explicitly wired in to replace this default.
RISK_WEIGHTS = {
    "age_over_45": 1,
    "bmi_overweight_or_above": 1,
    "previous_knee_injury": 1,
    "knee_pain_borderline": 1,
    "knee_pain_severe": 2,
    "morning_stiffness": 1,
    "stair_difficulty": 1,
    "knee_rom_borderline": 1,
    "knee_rom_abnormal": 2,
    "cadence_borderline": 1,
    "cadence_abnormal": 2,
    "gait_asymmetry_borderline": 1,
    "gait_asymmetry_abnormal": 2,
    "pressure_asymmetry_borderline": 1,
    "pressure_asymmetry_abnormal": 2,
}

# Final category cut-offs on the additive score above.
RISK_CATEGORY_THRESHOLDS = {
    "low_max": 3,        # score <= 3  -> Low Risk
    "moderate_max": 7,   # 4-7         -> Moderate Risk
    # score >= 8          -> High Risk
}

AGE_RISK_CUTOFF = 45  # age >= this is counted as an OA risk factor

# ----------------------------------------------------------------------
# AI Posture Detection thresholds (Hip-Knee-Ankle alignment angle)
# ----------------------------------------------------------------------
# AI (Google's MediaPipe Pose model) is used ONLY to locate the hip, knee
# and ankle landmarks in an uploaded lower-limb photo. The Hip-Knee-Ankle
# (HKA) angle is then plain trigonometry, and the risk interpretation
# below is a plain threshold comparison -- not a trained OA classifier.
# 180 degrees = a perfectly straight hip-knee-ankle line (neutral
# alignment). A placeholder clinical range is used below -- calibrate
# with validated reference data for your target population.
POSTURE_KNEE_ANGLE_THRESHOLDS = {
    "normal_min_degrees": 175.0,
    "normal_max_degrees": 185.0,
    # < normal_min_degrees -> Varus deviation; > normal_max_degrees -> Valgus deviation
}

# Left-right HKA angle difference, in degrees, above which asymmetry is flagged.
POSTURE_ASYMMETRY_MAX_DEGREES = 5.0

# MediaPipe landmark visibility (0-1) required to DRAW that keypoint on
# the annotated overlay image.
POSTURE_LEG_VISIBILITY_THRESHOLD = 0.6

# MediaPipe landmark visibility (0-1) required to USE that keypoint in
# the angle calculation -- more lenient, since hip/knee/ankle are
# essential to the measurement even when only partially visible.
POSTURE_CORE_JOINT_MIN_VISIBILITY = 0.4
