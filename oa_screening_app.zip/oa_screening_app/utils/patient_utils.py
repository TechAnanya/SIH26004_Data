"""
Patient data helpers: BMI calculation and basic input validation.

These are plain, deterministic calculations -- no ML/AI involved.
"""

from dataclasses import dataclass, field
from datetime import date
from typing import Optional

from config.thresholds import BMI_THRESHOLDS


class ValidationError(Exception):
    """Raised when patient input fails a sanity check."""


@dataclass
class PatientInfo:
    patient_id: str
    patient_name: str
    age: int
    sex: str
    height_cm: float
    weight_kg: float
    location: str
    screening_date: date
    operator_id: str
    bmi: Optional[float] = field(default=None)
    bmi_category: Optional[str] = field(default=None)


@dataclass
class PatientHistory:
    previous_knee_injury: bool
    knee_pain_score: int
    morning_stiffness: bool
    stair_difficulty: bool


def calculate_bmi(height_cm: float, weight_kg: float) -> float:
    """
    Calculate Body Mass Index (BMI) from height (cm) and weight (kg).

    BMI = weight(kg) / height(m)^2

    Raises ValidationError for non-physiological or missing values so
    callers can surface a clear message to the healthcare worker instead
    of crashing or silently producing a nonsensical number.
    """
    if height_cm is None or weight_kg is None:
        raise ValidationError("Height and weight are required to calculate BMI.")

    try:
        height_cm = float(height_cm)
        weight_kg = float(weight_kg)
    except (TypeError, ValueError):
        raise ValidationError("Height and weight must be numeric values.")

    if height_cm <= 0 or weight_kg <= 0:
        raise ValidationError("Height and weight must be greater than zero.")

    # Sanity bounds to catch obvious data-entry errors (e.g. height in
    # metres entered as cm, or an implausible weight).
    if not (50 <= height_cm <= 250):
        raise ValidationError(
            "Height value looks invalid (expected between 50 cm and 250 cm)."
        )
    if not (2 <= weight_kg <= 400):
        raise ValidationError(
            "Weight value looks invalid (expected between 2 kg and 400 kg)."
        )

    height_m = height_cm / 100.0
    bmi = weight_kg / (height_m ** 2)
    return round(bmi, 1)


def classify_bmi(bmi: float) -> str:
    """Map a BMI value to a standard WHO adult category label."""
    if bmi is None:
        return "Unknown"
    if bmi < BMI_THRESHOLDS["underweight_max"]:
        return "Underweight"
    if bmi <= BMI_THRESHOLDS["normal_max"]:
        return "Normal"
    if bmi <= BMI_THRESHOLDS["overweight_max"]:
        return "Overweight"
    return "Obese"


def validate_patient_info(
    patient_id: str,
    patient_name: str,
    age,
    sex: str,
    height_cm,
    weight_kg,
    location: str,
    operator_id: str,
) -> list:
    """
    Validate basic patient information. Returns a list of human-readable
    error strings (empty list means valid).
    """
    errors = []

    if not patient_id or not str(patient_id).strip():
        errors.append("Patient ID is required.")
    if not patient_name or not str(patient_name).strip():
        errors.append("Patient name is required.")
    if not operator_id or not str(operator_id).strip():
        errors.append("Healthcare worker / operator ID is required.")
    if not location or not str(location).strip():
        errors.append("Location is required.")
    if sex not in ("Male", "Female", "Other"):
        errors.append("Sex must be specified.")

    try:
        age_val = int(age)
        if not (0 < age_val < 130):
            errors.append("Age looks invalid (expected between 1 and 129).")
    except (TypeError, ValueError):
        errors.append("Age must be a whole number.")

    try:
        calculate_bmi(height_cm, weight_kg)
    except ValidationError as e:
        errors.append(str(e))

    return errors


def validate_patient_history(
    previous_knee_injury,
    knee_pain_score,
    morning_stiffness,
    stair_difficulty,
) -> list:
    """Validate patient history / symptom inputs."""
    errors = []

    if previous_knee_injury not in (True, False):
        errors.append("Previous knee injury must be answered Yes/No.")
    if morning_stiffness not in (True, False):
        errors.append("Morning knee stiffness must be answered Yes/No.")
    if stair_difficulty not in (True, False):
        errors.append("Difficulty climbing stairs must be answered Yes/No.")

    try:
        score = int(knee_pain_score)
        if not (0 <= score <= 10):
            errors.append("Knee pain score must be between 0 and 10.")
    except (TypeError, ValueError):
        errors.append("Knee pain score must be a whole number between 0 and 10.")

    return errors
