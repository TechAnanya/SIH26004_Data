"""
Shared heatmap-overlay and high-activation-region helpers, used by both
Grad-CAM and Score-CAM so the visual style (color map, blending) and the
bounding-box logic stay identical across explainability methods.
"""

from typing import Tuple

import numpy as np
import cv2


def overlay_heatmap(base_rgb: np.ndarray, heatmap: np.ndarray, alpha: float = 0.4) -> np.ndarray:
    """Blend a normalized [0, 1] heatmap onto a uint8 RGB image using a JET color map."""
    h, w = base_rgb.shape[:2]
    heatmap_resized = cv2.resize(heatmap, (w, h))
    heatmap_uint8 = np.uint8(255 * np.clip(heatmap_resized, 0, 1))
    heatmap_color = cv2.applyColorMap(heatmap_uint8, cv2.COLORMAP_JET)
    heatmap_color = cv2.cvtColor(heatmap_color, cv2.COLOR_BGR2RGB)

    overlay = (base_rgb.astype(np.float32) * (1 - alpha) + heatmap_color.astype(np.float32) * alpha)
    return np.uint8(np.clip(overlay, 0, 255))


def get_high_activation_regions(
    heatmap: np.ndarray,
    raw_image: np.ndarray,
    percentile: float = 85.0,
    min_area: int = 100,
) -> Tuple[np.ndarray, np.ndarray, float, int]:
    """
    Threshold a heatmap at the given percentile, clean the resulting mask
    up morphologically, and draw bounding boxes around the surviving
    high-activation regions on top of `raw_image`.

    Returns (highlighted_rgb, mask_rgb, threshold_value, region_count).
    `heatmap` may be at native (small) convolutional resolution -- it is
    scaled UP to match `raw_image`'s resolution, not the other way
    around.
    """
    original_uint8 = np.clip(raw_image, 0, 255).astype(np.uint8)
    h, w = original_uint8.shape[:2]
    if heatmap.shape[:2] != (h, w):
        heatmap = cv2.resize(heatmap, (w, h))

    threshold = float(np.percentile(heatmap, percentile))
    binary_mask = (heatmap >= threshold).astype(np.uint8) * 255

    kernel = np.ones((5, 5), np.uint8)
    binary_mask = cv2.morphologyEx(binary_mask, cv2.MORPH_OPEN, kernel)
    binary_mask = cv2.morphologyEx(binary_mask, cv2.MORPH_CLOSE, kernel)

    contours, _ = cv2.findContours(binary_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    highlighted = original_uint8.copy()
    region_count = 0
    for contour in contours:
        if cv2.contourArea(contour) < min_area:
            continue
        x, y, cw, ch = cv2.boundingRect(contour)
        cv2.rectangle(highlighted, (x, y), (x + cw, y + ch), (255, 255, 0), 2)
        region_count += 1

    mask_rgb = cv2.cvtColor(binary_mask, cv2.COLOR_GRAY2RGB)
    return highlighted, mask_rgb, threshold, region_count
