"""
Grad-CAM explainability visualization for the Software OA Risk Marker.

Produces a heatmap overlay showing which regions of the X-ray most
influenced the G5 model's prediction. This is an AI EXPLAINABILITY aid
only -- it is not independent clinical proof of a lesion and must always
be labelled as such wherever it is shown or included in a report.

The target layer is architecture-specific and configurable
(config.settings.G5_GRADCAM_TARGET_LAYER / G5_GRADCAM_BASE_LAYER_NAME).
Discovery (including the nested-backbone handling and a 4D-output-shape
fallback) lives in utils/tf_architecture.py, shared with Score-CAM.
"""

from dataclasses import dataclass
from typing import Optional

import numpy as np

from config import settings
from utils.model_loader import ModelLoadResult
from utils.image_utils import PreparedImage
from utils.heatmap_utils import overlay_heatmap


@dataclass
class GradCamResult:
    success: bool
    overlay_rgb: Optional[np.ndarray] = None  # uint8 (H, W, 3), original + heatmap
    heatmap: Optional[np.ndarray] = None      # float32 (H, W) in [0, 1]
    error: Optional[str] = None


def generate_gradcam(
    model_result: ModelLoadResult,
    prepared_image: PreparedImage,
    target_class_index: int,
    target_layer_name: Optional[str] = None,
    base_layer_name: Optional[str] = None,
) -> GradCamResult:
    if not model_result.loaded or model_result.model is None:
        return GradCamResult(success=False, error=model_result.error or "The G5 model is not loaded.")

    target_layer_name = target_layer_name or settings.G5_GRADCAM_TARGET_LAYER
    base_layer_name = base_layer_name if base_layer_name is not None else settings.G5_GRADCAM_BASE_LAYER_NAME

    try:
        if model_result.backend == "pytorch":
            heatmap = _gradcam_pytorch(model_result.model, prepared_image.array, target_class_index, target_layer_name)
        elif model_result.backend == "tensorflow":
            heatmap = _gradcam_tensorflow(
                model_result.model, prepared_image.array, target_class_index, target_layer_name, base_layer_name
            )
        else:
            return GradCamResult(success=False, error=f"Unsupported backend '{model_result.backend}' for Grad-CAM.")
    except Exception as exc:  # noqa: BLE001
        return GradCamResult(
            success=False,
            error=(
                f"Grad-CAM generation failed for target layer "
                f"'{target_layer_name}'. Verify this layer name exists in "
                f"the G5 model architecture. Details: {exc}"
            ),
        )

    overlay = overlay_heatmap(prepared_image.resized_rgb, heatmap)
    return GradCamResult(success=True, overlay_rgb=overlay, heatmap=heatmap)


def _gradcam_pytorch(model, array: np.ndarray, target_class_index: int, layer_name: str) -> np.ndarray:
    import torch

    if not layer_name:
        raise ValueError(
            "No Grad-CAM target layer is configured (config.settings.G5_GRADCAM_TARGET_LAYER)."
        )

    # `array` is channel-last (1, H, W, 3); PyTorch models expect
    # channel-first (1, 3, H, W).
    nchw = np.transpose(array, (0, 3, 1, 2))

    device = next(model.parameters()).device if hasattr(model, "parameters") else torch.device("cpu")
    tensor = torch.from_numpy(nchw).to(device)
    tensor.requires_grad_(True)

    target_layer = dict(model.named_modules()).get(layer_name)
    if target_layer is None:
        raise ValueError(f"Layer '{layer_name}' was not found in the model's named modules.")

    activations = {}
    gradients = {}

    def fwd_hook(module, inp, out):
        activations["value"] = out

    def bwd_hook(module, grad_in, grad_out):
        gradients["value"] = grad_out[0]

    h1 = target_layer.register_forward_hook(fwd_hook)
    h2 = target_layer.register_full_backward_hook(bwd_hook)

    try:
        model.zero_grad()
        output = model(tensor)
        if isinstance(output, (tuple, list)):
            output = output[0]
        output = output.squeeze()
        if output.ndim == 0:
            score = output
        else:
            score = output[target_class_index]
        score.backward()

        acts = activations["value"].detach().cpu().numpy()[0]      # (C, H, W)
        grads = gradients["value"].detach().cpu().numpy()[0]       # (C, H, W)
    finally:
        h1.remove()
        h2.remove()

    weights = np.mean(grads, axis=(1, 2))  # (C,)
    cam = np.zeros(acts.shape[1:], dtype=np.float32)
    for i, w in enumerate(weights):
        cam += w * acts[i]

    cam = np.maximum(cam, 0)
    if cam.max() > 0:
        cam = cam / cam.max()
    return cam


def _gradcam_tensorflow(
    model, array: np.ndarray, target_class_index: int, layer_name: str, base_layer_name: Optional[str] = None
) -> np.ndarray:
    """
    Grad-CAM for the supplied G5 model's architecture: an outer Keras
    functional model whose EfficientNetB0 backbone is a NESTED sub-model
    (named `base_layer_name`, e.g. "efficientnetb0"), followed by a
    classification head (GlobalAveragePooling2D -> Dropout -> Dense).

    Builds a grad-model from the backbone's own input to (conv layer
    output, backbone output), then manually replays the head layers that
    come after the backbone in the outer model, inside the gradient tape
    -- this avoids the Keras "graph disconnected" error that a naive
    `Model(model.input, conv_layer.output)` would raise for a layer that
    lives inside a nested sub-model.

    Falls back to a flat (non-nested) lookup directly on `model` if no
    nested backbone is found (see utils/tf_architecture.py).
    """
    import tensorflow as tf
    from utils.tf_architecture import discover_gradcam_targets

    tf_array = tf.convert_to_tensor(array, dtype=tf.float32)  # already channel-last (1, H, W, 3)

    base_model, conv_layer, base_idx = discover_gradcam_targets(model, base_layer_name, layer_name)

    if conv_layer is None:
        container = base_model if base_model is not None else model
        raise ValueError(
            f"Could not find a suitable convolutional layer for Grad-CAM "
            f"(looked for '{layer_name}'). Available layers: {[l.name for l in container.layers]}"
        )

    if base_model is not None:
        grad_model = tf.keras.models.Model(base_model.inputs, [conv_layer.output, base_model.output])
        head_layers = model.layers[base_idx + 1:]

        with tf.GradientTape() as tape:
            conv_outputs, base_output = grad_model(tf_array, training=False)
            x = base_output
            for layer in head_layers:
                x = layer(x)
            predictions = tf.squeeze(x)
            loss = predictions if len(predictions.shape) == 0 else predictions[target_class_index]

        grads = tape.gradient(loss, conv_outputs)
    else:
        grad_model = tf.keras.models.Model([model.inputs], [conv_layer.output, model.output])

        with tf.GradientTape() as tape:
            conv_outputs, predictions = grad_model(tf_array, training=False)
            predictions = tf.squeeze(predictions)
            loss = predictions if len(predictions.shape) == 0 else predictions[target_class_index]

        grads = tape.gradient(loss, conv_outputs)

    if grads is None:
        raise ValueError(
            "Gradients could not be computed for the specified layer "
            "(it may not be part of the model's differentiable path)."
        )

    conv_outputs = conv_outputs[0]
    grads = grads[0]

    # Global-average-pooled gradients as channel importance weights,
    # weighted sum over the conv feature maps -- standard Grad-CAM.
    pooled_grads = tf.reduce_mean(grads, axis=(0, 1))
    heatmap = conv_outputs @ pooled_grads[..., tf.newaxis]
    heatmap = tf.squeeze(heatmap)
    heatmap = tf.maximum(heatmap, 0) / (tf.math.reduce_max(heatmap) + 1e-8)

    return heatmap.numpy()
