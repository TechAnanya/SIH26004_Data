"""
Shared architecture-discovery helpers for a Keras/TensorFlow G5 model.

The supplied model wraps its EfficientNetB0 backbone as a NESTED
sub-model (a layer that is itself a Keras Model, e.g. named
"efficientnetb0") inside an outer classification model. Both Grad-CAM
and Score-CAM need to reach inside that nested sub-model to find the
final convolutional layer, then replay the classification head
(GlobalAveragePooling2D -> Dropout -> Dense) manually -- this module is
the ONE place that logic lives, so both explainability methods (and any
future one) stay in sync.

Discovery is layered so a slightly different EfficientNet variant, a
differently-named layer, or a retrained/flat (non-nested) model still
works without code changes:
  1. Try the configured name exactly (fast path, matches the training
     notebook precisely).
  2. Fall back to scanning for a substring match.
  3. Fall back to the last layer with a 4D output shape (a plain
     convolutional feature map), which is architecture-agnostic.
"""

from typing import Optional, Tuple


def find_base_model(main_model, base_layer_name_hint: Optional[str] = None):
    """
    Return the nested backbone sub-model (a layer that is itself a Keras
    Model), or None if the model is flat (not built with a nested
    backbone) -- in which case callers should treat `main_model` itself
    as the layer container.
    """
    from tensorflow import keras

    if base_layer_name_hint:
        try:
            layer = main_model.get_layer(base_layer_name_hint)
            if isinstance(layer, keras.Model):
                return layer
        except Exception:
            pass

    nested = [l for l in main_model.layers if isinstance(l, keras.Model)]
    if not nested:
        return None

    if base_layer_name_hint:
        for l in nested:
            if base_layer_name_hint.lower() in l.name.lower():
                return l

    # No name hint matched -- fall back to the first nested sub-model found.
    return nested[0]


def find_last_conv_layer(container, target_layer_hint: Optional[str] = None):
    """
    Return the target convolutional layer within `container.layers`:
    exact name match, then the LAST layer whose name contains the hint
    as a substring (robust to EfficientNet variants), then -- if no hint
    matches at all -- the last layer with a 4D output shape.
    """
    if target_layer_hint:
        try:
            return container.get_layer(target_layer_hint)
        except Exception:
            pass

        matches = [l for l in container.layers if target_layer_hint in l.name]
        if matches:
            return matches[-1]

    for layer in reversed(container.layers):
        try:
            shape = layer.output.shape
            if len(shape) == 4:
                return layer
        except Exception:
            continue

    return None


def get_layer_index(model, layer) -> Optional[int]:
    for i, l in enumerate(model.layers):
        if l.name == layer.name:
            return i
    return None


def discover_gradcam_targets(
    model,
    base_layer_name_hint: Optional[str],
    target_layer_hint: Optional[str],
) -> Tuple[object, object, Optional[int]]:
    """
    Convenience wrapper used by both Grad-CAM and Score-CAM.

    Returns (base_model, conv_layer, base_model_index):
      - If the model is nested, base_model is the backbone sub-model and
        base_model_index is its position in `model.layers` (so callers
        can replay the layers that come after it as the classification
        head).
      - If the model is flat, base_model is None and conv_layer was
        searched directly on the top-level model; base_model_index is
        also None.
      - conv_layer is None only if no usable convolutional layer could
        be found at all -- callers should raise a clear error in that
        case rather than proceeding.
    """
    base_model = find_base_model(model, base_layer_name_hint)
    container = base_model if base_model is not None else model
    conv_layer = find_last_conv_layer(container, target_layer_hint)
    base_index = get_layer_index(model, base_model) if base_model is not None else None
    return base_model, conv_layer, base_index
