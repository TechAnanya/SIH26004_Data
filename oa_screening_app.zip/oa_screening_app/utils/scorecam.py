"""
Score-CAM explainability visualization for the Software OA Risk Marker.

Unlike Grad-CAM, Score-CAM needs no gradients: it masks the input image
with each of the backbone's strongest activation channels, re-runs the
FULL model on each masked image, and weights each channel's spatial map
by how much that masked image alone supports the predicted class. This
is a CPU-friendly implementation (channel count is capped and
configurable) since a full unmasked pass per channel can otherwise be
slow without a GPU.

Like Grad-CAM and LIME, this is an AI EXPLAINABILITY aid only -- it is
not independent clinical proof of a lesion or diagnosis.
"""

from dataclasses import dataclass
from typing import Optional

import numpy as np

from config import settings
from utils.model_loader import ModelLoadResult
from utils.image_utils import PreparedImage, preprocess_array
from utils.heatmap_utils import overlay_heatmap


@dataclass
class ScoreCamResult:
    success: bool
    overlay_rgb: Optional[np.ndarray] = None  # uint8 (H, W, 3)
    heatmap: Optional[np.ndarray] = None      # float32 (H, W) in [0, 1]
    error: Optional[str] = None


def generate_scorecam(
    model_result: ModelLoadResult,
    prepared_image: PreparedImage,
    target_class_index: int,
    max_channels: Optional[int] = None,
    target_layer_name: Optional[str] = None,
    base_layer_name: Optional[str] = None,
) -> ScoreCamResult:
    if not model_result.loaded or model_result.model is None:
        return ScoreCamResult(success=False, error=model_result.error or "The G5 model is not loaded.")

    if model_result.backend != "tensorflow":
        return ScoreCamResult(
            success=False,
            error="Score-CAM is currently only implemented for TensorFlow/Keras G5 models.",
        )

    max_channels = max_channels or settings.G5_SCORECAM_MAX_CHANNELS
    target_layer_name = target_layer_name or settings.G5_GRADCAM_TARGET_LAYER
    base_layer_name = base_layer_name if base_layer_name is not None else settings.G5_GRADCAM_BASE_LAYER_NAME

    try:
        heatmap = _scorecam_tensorflow(
            model_result.model,
            prepared_image.resized_rgb,
            target_class_index,
            base_layer_name,
            target_layer_name,
            max_channels,
        )
    except Exception as exc:  # noqa: BLE001
        return ScoreCamResult(
            success=False,
            error=f"Score-CAM generation failed. Details: {exc}",
        )

    overlay = overlay_heatmap(prepared_image.resized_rgb, heatmap)
    return ScoreCamResult(success=True, overlay_rgb=overlay, heatmap=heatmap)


def _scorecam_tensorflow(
    model,
    resized_rgb_uint8: np.ndarray,
    target_class_index: int,
    base_layer_name: Optional[str],
    target_layer_name: Optional[str],
    max_channels: int,
) -> np.ndarray:
    from tensorflow import keras
    import cv2
    from utils.tf_architecture import discover_gradcam_targets

    base_model, conv_layer, _ = discover_gradcam_targets(model, base_layer_name, target_layer_name)
    if conv_layer is None:
        container = base_model if base_model is not None else model
        raise ValueError(
            f"Could not find a suitable convolutional layer for Score-CAM "
            f"(looked for '{target_layer_name}'). Available layers: {[l.name for l in container.layers]}"
        )

    backbone = base_model if base_model is not None else model
    backbone_input = backbone.inputs if hasattr(backbone, "inputs") else backbone.input
    activation_model = keras.models.Model(inputs=backbone_input, outputs=conv_layer.output)

    raw_image = resized_rgb_uint8.astype(np.float32)  # (H, W, 3)
    h, w = raw_image.shape[0], raw_image.shape[1]

    processed = preprocess_array(resized_rgb_uint8)  # (1, H, W, 3), respects G5_PREPROCESS_MODE
    activations = activation_model.predict(processed, verbose=0)[0]  # (h', w', channels)
    total_channels = activations.shape[-1]

    # Rank channels by their own (ReLU'd) activation strength, strongest first.
    channel_scores = np.mean(np.maximum(activations, 0), axis=(0, 1))
    selected_channels = np.argsort(channel_scores)[::-1][: min(max_channels, total_channels)]

    masked_images = []
    masks = []
    for c in selected_channels:
        activation = np.maximum(activations[:, :, c], 0)
        max_val = activation.max()
        if max_val <= 1e-10:
            continue
        activation = activation / max_val

        mask = cv2.resize(activation, (w, h), interpolation=cv2.INTER_LINEAR)
        mask = np.clip(mask, 0, 1)

        masked_images.append(raw_image * mask[:, :, np.newaxis])
        masks.append(mask)

    if not masked_images:
        return np.zeros((h, w), dtype=np.float32)

    masked_processed = np.stack(
        [preprocess_array(img.astype(np.uint8))[0] for img in masked_images], axis=0
    ).astype(np.float32)

    predictions = model.predict(masked_processed, verbose=0, batch_size=16)
    class_scores = np.asarray(predictions)[:, target_class_index]

    heatmap = np.zeros((h, w), dtype=np.float32)
    for score, mask in zip(class_scores, masks):
        heatmap += float(score) * mask

    heatmap = np.maximum(heatmap, 0)
    max_val = heatmap.max()
    if max_val > 1e-10:
        heatmap = heatmap / max_val

    return heatmap
