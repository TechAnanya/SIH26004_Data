"""
Software OA Risk Marker -- deep-learning inference against the actual
supplied G5 model.

This module NEVER returns a random, fabricated, or placeholder
prediction. If the model is missing, fails to load, or fails during
inference, a PredictionResult with `success=False` and a descriptive
error is returned so the UI can show a clear "model not available"
message instead of a fake result.
"""

from dataclasses import dataclass, field
from typing import List, Optional

import numpy as np

from config import settings
from utils.model_loader import ModelLoadResult
from utils.image_utils import PreparedImage


@dataclass
class PredictionResult:
    success: bool
    predicted_label: Optional[str] = None
    predicted_index: Optional[int] = None
    probabilities: Optional[List[float]] = field(default=None)
    positive_class_label: Optional[str] = None
    positive_class_probability: Optional[float] = None
    joint_problem_detected: Optional[bool] = None
    assessment: Optional[str] = None  # "NORMAL" | "ABNORMAL"
    error: Optional[str] = None
    raw_logits: Optional[List[float]] = None


def _softmax(x: np.ndarray) -> np.ndarray:
    x = x - np.max(x)
    e = np.exp(x)
    return e / e.sum()


def predict_image(
    model_result: ModelLoadResult,
    prepared_image: PreparedImage,
    class_labels: Optional[List[str]] = None,
    positive_class_index: Optional[int] = None,
) -> PredictionResult:
    """
    Run the loaded G5 model on a preprocessed image and return the
    model's own predicted class + probability, using the class labels
    configured for the actual G5 model (config.settings.G5_CLASS_LABELS).
    """
    if not model_result.loaded or model_result.model is None:
        return PredictionResult(
            success=False,
            error=model_result.error or "The G5 model is not loaded.",
        )

    class_labels = class_labels or settings.G5_CLASS_LABELS
    positive_class_index = (
        positive_class_index
        if positive_class_index is not None
        else settings.G5_POSITIVE_CLASS_INDEX
    )

    try:
        if model_result.backend == "pytorch":
            probs = _predict_pytorch(model_result.model, prepared_image.array)
        elif model_result.backend == "tensorflow":
            probs = _predict_tensorflow(model_result.model, prepared_image.array)
        else:
            return PredictionResult(
                success=False,
                error=f"Unsupported model backend '{model_result.backend}'.",
            )
    except Exception as exc:  # noqa: BLE001
        return PredictionResult(
            success=False,
            error=(
                "Inference failed. This can happen if the image shape/"
                "preprocessing does not match what the G5 model expects, or "
                f"if the model architecture is incompatible. Details: {exc}"
            ),
        )

    if probs is None or len(probs) == 0:
        return PredictionResult(success=False, error="The model returned an empty prediction.")

    if len(class_labels) != len(probs):
        return PredictionResult(
            success=False,
            error=(
                f"The model produced {len(probs)} output value(s) but "
                f"{len(class_labels)} class label(s) are configured in "
                "config/settings.py (G5_CLASS_LABELS). Update the "
                "configuration to match the real G5 model's output classes."
            ),
        )

    predicted_index = int(np.argmax(probs))
    predicted_label = class_labels[predicted_index]

    if 0 <= positive_class_index < len(probs):
        positive_label = class_labels[positive_class_index]
        positive_prob = float(probs[positive_class_index])
        joint_problem_detected = positive_prob >= 0.5
        assessment = "ABNORMAL" if joint_problem_detected else "NORMAL"
    else:
        positive_label = predicted_label
        positive_prob = float(probs[predicted_index])
        joint_problem_detected = predicted_index == positive_class_index
        assessment = "ABNORMAL" if joint_problem_detected else "NORMAL"

    return PredictionResult(
        success=True,
        predicted_label=predicted_label,
        predicted_index=predicted_index,
        probabilities=[float(p) for p in probs],
        positive_class_label=positive_label,
        positive_class_probability=positive_prob,
        joint_problem_detected=joint_problem_detected,
        assessment=assessment,
    )


def _predict_pytorch(model, array: np.ndarray) -> np.ndarray:
    import torch

    # `array` from image_utils is channel-last (1, H, W, 3); PyTorch models
    # expect channel-first (1, 3, H, W).
    nchw = np.transpose(array, (0, 3, 1, 2))

    device = next(model.parameters()).device if hasattr(model, "parameters") else torch.device("cpu")
    tensor = torch.from_numpy(nchw).to(device)

    with torch.no_grad():
        output = model(tensor)

    if isinstance(output, (tuple, list)):
        output = output[0]

    output = output.detach().cpu().numpy().squeeze()

    # If the model already outputs a normalized distribution (sums to ~1),
    # trust it; otherwise treat outputs as logits and apply softmax.
    if output.ndim == 0:
        output = np.array([1 - float(output), float(output)])  # single sigmoid output

    total = float(np.sum(output))
    if 0.98 <= total <= 1.02 and np.all(output >= 0):
        probs = output
    else:
        probs = _softmax(output)

    return probs


def _predict_tensorflow(model, array: np.ndarray) -> np.ndarray:
    # `array` from image_utils is already channel-last (1, H, W, 3), which
    # is what Keras/TensorFlow models expect -- no transpose needed.
    output = model.predict(array, verbose=0)
    output = np.asarray(output).squeeze()

    if output.ndim == 0:
        output = np.array([1 - float(output), float(output)])

    total = float(np.sum(output))
    if 0.98 <= total <= 1.02 and np.all(output >= 0):
        probs = output
    else:
        probs = _softmax(output)

    return probs
