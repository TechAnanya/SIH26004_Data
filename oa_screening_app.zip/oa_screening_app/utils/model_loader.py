"""
G5 deep-learning model loader.

This module is responsible ONLY for locating and loading the actual,
externally-supplied G5 trained model file. It never fabricates a model,
never returns a stub/random predictor, and never silently substitutes a
placeholder. If the model cannot be found or loaded, `load_image_model()`
returns a ModelLoadResult with `loaded=False` and a clear, healthcare
worker-friendly error message that the UI must surface instead of
proceeding with a screening.

Supports two backends, auto-detected from the file extension:
  - PyTorch:      .pt / .pth        (torch.load + optional TorchScript)
  - TensorFlow:   .h5 / .keras / SavedModel directory
"""

import os

# Force TensorFlow to use its bundled legacy Keras 2 engine (the "tf_keras"
# compatibility package) instead of Keras 3, whenever a G5 .h5 model saved
# with an older TF/Keras (e.g. TF 2.15, as used in the training notebook)
# needs to be loaded. Keras 3 changed how it serializes/reconstructs the
# Functional-API graph for a layer that is called with extra arguments
# (the notebook does `base_model(inputs, training=False)`), which makes
# Keras 3 unable to reconstruct node connections that Keras 2 wrote --
# raising "Invalid Functional model configuration ... loops or
# disconnected nodes" even though the file itself is not corrupted.
# Loading with the actual Keras 2 engine (the one that wrote the file)
# avoids the incompatibility entirely, with no code changes needed
# elsewhere -- tf.keras.* below transparently becomes the legacy API.
# Requires the 'tf-keras' package (see requirements.txt). This MUST be
# set before the first `import tensorflow` anywhere in the process, so
# it lives here at module import time (utils/model_loader.py is imported
# well before any button click triggers a lazy TensorFlow import).
os.environ.setdefault("TF_USE_LEGACY_KERAS", "1")

from dataclasses import dataclass
from typing import Optional, Any

from config import settings


@dataclass
class ModelLoadResult:
    loaded: bool
    model: Optional[Any] = None
    backend: Optional[str] = None  # "pytorch" | "tensorflow"
    error: Optional[str] = None


def _detect_backend(model_path: str) -> Optional[str]:
    ext = os.path.splitext(model_path)[1].lower()
    if ext in (".pt", ".pth"):
        return "pytorch"
    if ext in (".h5", ".keras"):
        return "tensorflow"
    if os.path.isdir(model_path):
        # A TensorFlow SavedModel is a directory; a torch model is a file,
        # so a directory path is treated as SavedModel format.
        return "tensorflow"
    return None


def load_image_model(
    model_path: Optional[str] = None,
    backend: Optional[str] = None,
) -> ModelLoadResult:
    """
    Load the trained G5 model from disk.

    Parameters
    ----------
    model_path : path to the model file/directory. Defaults to
        config.settings.G5_MODEL_PATH.
    backend : force "pytorch" or "tensorflow". Defaults to
        config.settings.G5_MODEL_BACKEND ("auto" = detect from extension).

    Returns
    -------
    ModelLoadResult
    """
    model_path = model_path or settings.G5_MODEL_PATH
    backend = backend or settings.G5_MODEL_BACKEND

    if not model_path or not os.path.exists(model_path):
        return ModelLoadResult(
            loaded=False,
            error=(
                "The G5 model file was not found at the configured path "
                f"({model_path}). Please place the trained G5 model file in "
                "the 'models' folder (or set the G5_MODEL_PATH environment "
                "variable) and reload the Software OA Risk Marker."
            ),
        )

    if backend == "auto":
        backend = _detect_backend(model_path)
        if backend is None:
            return ModelLoadResult(
                loaded=False,
                error=(
                    "Could not automatically determine the model format for "
                    f"'{model_path}'. Supported formats are PyTorch (.pt, "
                    ".pth) and TensorFlow/Keras (.h5, .keras, or a "
                    "SavedModel folder). Set G5_MODEL_BACKEND explicitly if "
                    "needed."
                ),
            )

    try:
        if backend == "pytorch":
            return _load_pytorch_model(model_path)
        elif backend == "tensorflow":
            return _load_tensorflow_model(model_path)
        else:
            return ModelLoadResult(
                loaded=False,
                error=f"Unknown model backend '{backend}'. Use 'pytorch' or 'tensorflow'.",
            )
    except Exception as exc:  # noqa: BLE001 - surface any load failure clearly
        return ModelLoadResult(
            loaded=False,
            error=(
                "The G5 model could not be loaded. This usually means the "
                "model file is incompatible, corrupted, or was saved with a "
                f"different architecture/library version. Details: {exc}"
            ),
        )


def _load_pytorch_model(model_path: str) -> ModelLoadResult:
    try:
        import torch
    except ImportError:
        return ModelLoadResult(
            loaded=False,
            error=(
                "PyTorch is not installed in this environment. Install it "
                "with 'pip install torch' to load the .pt/.pth G5 model."
            ),
        )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # Try TorchScript first (self-contained, architecture included).
    try:
        model = torch.jit.load(model_path, map_location=device)
        model.eval()
        return ModelLoadResult(loaded=True, model=model, backend="pytorch")
    except Exception:
        pass

    # Fall back to a plain torch.load (a full pickled nn.Module, or a
    # state_dict). A bare state_dict cannot be used without the original
    # model class, so that case is reported clearly rather than guessed at.
    loaded_obj = torch.load(model_path, map_location=device, weights_only=False)

    if hasattr(loaded_obj, "eval") and callable(getattr(loaded_obj, "eval")):
        loaded_obj.eval()
        loaded_obj.to(device)
        return ModelLoadResult(loaded=True, model=loaded_obj, backend="pytorch")

    if isinstance(loaded_obj, dict):
        raise RuntimeError(
            "The file contains only a state_dict (model weights) without the "
            "model architecture/class. Export the full model with "
            "torch.jit.script/torch.jit.trace, or update model_loader.py "
            "with the exact G5 model class definition so the state_dict can "
            "be loaded into it."
        )

    raise RuntimeError("The loaded object is not a usable PyTorch model.")


def _load_tensorflow_model(model_path: str) -> ModelLoadResult:
    try:
        import tensorflow as tf
    except ImportError as exc:
        if "tf_keras" in str(exc) or "tf-keras" in str(exc):
            return ModelLoadResult(
                loaded=False,
                error=(
                    "This model needs TensorFlow's legacy Keras 2 engine to load "
                    "correctly (it was saved with an older TF/Keras version), which "
                    "requires the 'tf-keras' package. Install it with "
                    "'pip install tf-keras' and try again."
                ),
            )
        return ModelLoadResult(
            loaded=False,
            error=(
                "TensorFlow is not installed in this environment. Install "
                "it with 'pip install tensorflow' to load the G5 model "
                "(.h5, .keras, or SavedModel)."
            ),
        )

    try:
        model = tf.keras.models.load_model(model_path, compile=False)
    except (TypeError, ValueError) as exc:
        if "DepthwiseConv2D" in str(exc) and "groups" in str(exc):
            # Known Keras-2 -> Keras-3 compatibility break: older TF/Keras
            # (e.g. TF 2.15, used to train many EfficientNet models)
            # serialized DepthwiseConv2D with a 'groups' config key that
            # Keras 3's DepthwiseConv2D no longer accepts. Shim it away by
            # loading with a custom_objects override that just drops the
            # obsolete kwarg before construction.
            class _CompatDepthwiseConv2D(tf.keras.layers.DepthwiseConv2D):
                def __init__(self, *args, **kwargs):
                    kwargs.pop("groups", None)
                    super().__init__(*args, **kwargs)

            model = tf.keras.models.load_model(
                model_path,
                compile=False,
                custom_objects={"DepthwiseConv2D": _CompatDepthwiseConv2D},
            )
        else:
            raise

    return ModelLoadResult(loaded=True, model=model, backend="tensorflow")
