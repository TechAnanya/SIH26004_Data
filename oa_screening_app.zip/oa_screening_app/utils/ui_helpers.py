"""
Small reusable HTML/CSS rendering helpers for the Streamlit UI so the
dashboard has a consistent, non-default appearance across every page.
"""

import os
import streamlit as st

from config.settings import (
    BASE_DIR, APP_NAME, APP_TAGLINE, MEDICAL_DISCLAIMER,
    TEAM_NAME, SIH_PS_NUMBER, SIH_PS_TITLE, SIH_PS_ORGANIZATION,
    SIH_PS_CATEGORY, SIH_PS_THEME,
)


def inject_css():
    css_path = os.path.join(BASE_DIR, "assets", "style.css")
    with open(css_path, "r", encoding="utf-8") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)


def top_bar(badge_text: str = "Preliminary Screening Tool"):
    # NOTE: built as ONE line with no embedded newlines/indentation. A
    # multi-line, indented f-string here gets misread by Streamlit's
    # markdown renderer as an indented code block, which prints the raw
    # "<div>...</div>" tags as literal text instead of rendering them.
    st.markdown(
        f'<div class="oa-topbar"><div><h1>{APP_NAME}</h1><p>{APP_TAGLINE}</p>'
        f'<p class="oa-sih-meta">Team {TEAM_NAME} &nbsp;·&nbsp; Smart India Hackathon &nbsp;·&nbsp; PS# {SIH_PS_NUMBER}</p></div>'
        f'<div class="oa-badge">{badge_text}</div></div>',
        unsafe_allow_html=True,
    )


def problem_statement_card():
    """SIH problem-statement context card, shown on the Dashboard so a
    reviewer/judge sees the team and PS details at a glance."""
    st.markdown(
        f'<div class="oa-ps-card"><div class="ps-title">{SIH_PS_TITLE}</div>'
        f'<div class="ps-row">'
        f'<span><b>Team:</b> {TEAM_NAME}</span>'
        f'<span><b>PS Number:</b> {SIH_PS_NUMBER}</span>'
        f'<span><b>Category:</b> {SIH_PS_CATEGORY}</span>'
        f'<span><b>Theme:</b> {SIH_PS_THEME}</span>'
        f'<span><b>Organization:</b> {SIH_PS_ORGANIZATION}</span>'
        f'</div></div>',
        unsafe_allow_html=True,
    )


def status_badge(status: str) -> str:
    cls = status.lower()
    return f'<span class="oa-status {cls}">{status}</span>'


def card_open(title: str = None):
    html = '<div class="oa-card">'
    if title:
        html += f'<div class="oa-section-title">{title}</div>'
    st.markdown(html, unsafe_allow_html=True)


def card_close():
    st.markdown("</div>", unsafe_allow_html=True)


def step_indicator(steps, current_index: int):
    parts = []
    for i, s in enumerate(steps):
        cls = "active" if i == current_index else ("done" if i < current_index else "")
        parts.append(f'<div class="oa-step {cls}">{i + 1}. {s}</div>')
    st.markdown(f'<div class="oa-steps">{"".join(parts)}</div>', unsafe_allow_html=True)


def metric_card(value: str, label: str):
    st.markdown(
        f"""<div class="oa-metric-card"><div class="val">{value}</div><div class="lbl">{label}</div></div>""",
        unsafe_allow_html=True,
    )


def risk_banner(score, category: str, subtitle: str = ""):
    cls_map = {"Low Risk": "low", "Moderate Risk": "moderate", "High Risk": "high"}
    cls = cls_map.get(category, "moderate")
    score_html = f'<div class="score">{score}</div>' if score is not None else ""
    # Built as ONE line -- see the note in top_bar() above for why: an
    # indented multi-line string here was rendering as literal
    # "<div class=...>" text instead of a styled banner.
    st.markdown(
        f'<div class="oa-risk-banner {cls}">{score_html}'
        f'<div class="label">{category}</div>'
        f'<div class="sub">{subtitle}</div></div>',
        unsafe_allow_html=True,
    )


def demo_ribbon(text="Demonstration / Manual Input Mode — ESP32 hardware not connected"):
    st.markdown(f'<div class="oa-demo-ribbon">{text}</div>', unsafe_allow_html=True)


def disclaimer_block():
    st.markdown(f'<div class="oa-disclaimer">{MEDICAL_DISCLAIMER}</div>', unsafe_allow_html=True)
