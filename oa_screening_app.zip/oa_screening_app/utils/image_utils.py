"""
X-ray image validation and preprocessing for the Software OA Risk Marker.

Handles: file-type validation, corrupted-image detection, resizing and
normalization to the shape/statistics the G5 model expects.
"""

import io
import os
from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np
from PIL import Image, UnidentifiedImageError

from config import settings


class ImageValidationError(Exception):
    """Raised when an uploaded file fails validation."""


@dataclass
class PreparedImage:
    original: Image.Image          # RGB PIL image, original resolution (for display)
    array: np.ndarray              # preprocessed float32 array ready for inference, channel-last (1, H, W, 3)
    resized_rgb: np.ndarray        # uint8 resized RGB array (H, W, 3) -- for display and the Grad-CAM overlay


def validate_uploaded_file(filename: str, file_bytes: bytes) -> None:
    """Raise ImageValidationError with a clear message if the upload is invalid."""
    if not filename:
        raise ImageValidationError("No file was uploaded.")

    ext = os.path.splitext(filename)[1].lower().lstrip(".")
    if ext not in settings.ALLOWED_IMAGE_EXTENSIONS:
        raise ImageValidationError(
            f"Unsupported file type '.{ext}'. Please upload a JPG, JPEG, or PNG image."
        )

    if not file_bytes:
        raise ImageValidationError("The uploaded file is empty.")

    size_mb = len(file_bytes) / (1024 * 1024)
    if size_mb > settings.MAX_UPLOAD_SIZE_MB:
        raise ImageValidationError(
            f"The uploaded file is too large ({size_mb:.1f} MB). "
            f"Maximum allowed size is {settings.MAX_UPLOAD_SIZE_MB} MB."
        )

    try:
        img = Image.open(io.BytesIO(file_bytes))
        img.verify()  # checks integrity without fully decoding
    except (UnidentifiedImageError, OSError, ValueError) as exc:
        raise ImageValidationError(
            "The uploaded file could not be read as a valid image. It may be "
            f"corrupted or not a real image file. Details: {exc}"
        )


def preprocess_array(
    resized_arr: np.ndarray,
    mode: Optional[str] = None,
    normalize_mean: Optional[Tuple[float, float, float]] = None,
    normalize_std: Optional[Tuple[float, float, float]] = None,
) -> np.ndarray:
    """
    Apply the configured preprocessing mode to an already-resized uint8
    (H, W, 3) RGB array and return a batched (1, H, W, 3) float32 array,
    channel-last (Keras/TensorFlow convention).

    mode:
      - "none"              raw 0-255 float pixels, no scaling. This is
                             what Keras's EfficientNet preprocess_input()
                             effectively does (it's an identity function --
                             normalization is built into the model), so it
                             is the correct setting for the supplied G5
                             model.
      - "rescale_0_1"       divide by 255.
      - "imagenet_normalize" divide by 255, then subtract mean / divide by
                             std (for a PyTorch-style G5 model).
    """
    mode = mode or settings.G5_PREPROCESS_MODE
    float_arr = resized_arr.astype(np.float32)

    if mode == "none":
        processed = float_arr
    elif mode == "rescale_0_1":
        processed = float_arr / 255.0
    elif mode == "imagenet_normalize":
        normalize_mean = normalize_mean or settings.G5_NORMALIZE_MEAN
        normalize_std = normalize_std or settings.G5_NORMALIZE_STD
        mean = np.array(normalize_mean, dtype=np.float32)
        std = np.array(normalize_std, dtype=np.float32)
        processed = (float_arr / 255.0 - mean) / std
    else:
        raise ImageValidationError(
            f"Unknown G5_PREPROCESS_MODE '{mode}'. Use 'none', 'rescale_0_1', or 'imagenet_normalize'."
        )

    return np.expand_dims(processed, axis=0).astype(np.float32)


def load_and_preprocess_image(
    file_bytes: bytes,
    target_size: Optional[Tuple[int, int]] = None,
) -> PreparedImage:
    """
    Decode, resize, and preprocess an X-ray image for model inference.

    Returns a PreparedImage with:
      - original: the original RGB image (for report/preview display)
      - array: a (1, H, W, 3) float32 array, channel-last, preprocessed
        according to config.settings.G5_PREPROCESS_MODE
      - resized_rgb: the resized uint8 RGB array (H, W, 3), used as the
        base image for display and the Grad-CAM overlay
    """
    target_size = target_size or settings.G5_INPUT_SIZE

    try:
        img = Image.open(io.BytesIO(file_bytes))
        img.load()
    except (UnidentifiedImageError, OSError, ValueError) as exc:
        raise ImageValidationError(f"Failed to decode image: {exc}")

    # Normalize color mode (X-rays are often grayscale; models are usually
    # trained on 3-channel input).
    original_rgb = img.convert("RGB")

    resized = original_rgb.resize(target_size, Image.BILINEAR)
    resized_arr = np.array(resized, dtype=np.uint8)  # (H, W, 3)

    batched = preprocess_array(resized_arr)

    return PreparedImage(original=original_rgb, array=batched, resized_rgb=resized_arr)
