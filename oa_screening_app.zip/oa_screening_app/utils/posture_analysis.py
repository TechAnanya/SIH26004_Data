"""
AI Posture Detection -- lower-limb (Hip-Knee-Ankle) alignment analysis.

Landmark extraction is done by Google's MediaPipe Pose model -- that is
the ONLY AI component of this pathway. Once the hip/knee/ankle keypoints
are found, the Hip-Knee-Ankle (HKA) angle is computed with plain
trigonometry and compared against fixed threshold values in
config/thresholds.py -- exactly the same "rule engine on top of a
measurement" pattern as the Hardware pathway's
utils/hardware_risk_engine.py. Nothing here is a trained OA classifier:
MediaPipe only locates body landmarks, it does not predict OA or any
diagnosis.

This module contains no Streamlit code -- see
components/posture_module.py for the UI layer.
"""

from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np
import cv2

from config import thresholds as th

try:
    import mediapipe as mp
    # Some mediapipe wheels (version/platform dependent) install without
    # the legacy `solutions` API this module relies on (mp.solutions.pose)
    # -- only the newer Tasks API is present. Verify it eagerly here so a
    # missing `solutions` submodule is reported as a clear, actionable
    # error instead of an AttributeError deep inside analyze_posture_image().
    _ = mp.solutions.pose
    _MEDIAPIPE_AVAILABLE = True
    _MP_IMPORT_ERROR: Optional[str] = None
except ImportError as exc:  # pragma: no cover - exercised only without the package
    mp = None
    _MEDIAPIPE_AVAILABLE = False
    _MP_IMPORT_ERROR = str(exc)
except AttributeError as exc:
    _MEDIAPIPE_AVAILABLE = False
    _MP_IMPORT_ERROR = (
        "mediapipe is installed but this build does not include the legacy "
        "'solutions' API (mediapipe.solutions.pose) that AI Posture "
        "Detection needs -- only the newer Tasks API is present. Try "
        "reinstalling with 'pip install --force-reinstall mediapipe' "
        "(some minimal/edge wheels omit the Solutions API), or use a "
        "different Python version (3.9-3.11 are most reliable for the "
        f"legacy API). Details: {exc}"
    )


# Display numbering used for the on-image labels / legend (matches the
# original reference script) -- these are NOT MediaPipe's own landmark
# indices, just a compact 11-16 numbering for the six leg joints shown.
KEYPOINT_NAMES = {
    11: "Left Hip",
    12: "Right Hip",
    13: "Left Knee",
    14: "Right Knee",
    15: "Left Ankle",
    16: "Right Ankle",
}
LEG_CONNECTIONS = [(11, 13), (13, 15), (12, 14), (14, 16)]
LEG_COLOR = (0, 165, 255)


def mediapipe_available() -> Tuple[bool, Optional[str]]:
    """Returns (True, None) if mediapipe is importable, else (False, error)."""
    return _MEDIAPIPE_AVAILABLE, _MP_IMPORT_ERROR


@dataclass
class PostureAnalysisResult:
    success: bool
    error: Optional[str] = None
    knee_angle_right: Optional[float] = None
    knee_angle_left: Optional[float] = None
    angle_asymmetry: Optional[float] = None
    risk_flag_right: bool = False
    risk_flag_left: bool = False
    risk_flag_asymmetry: bool = False
    overall_risk: bool = False
    low_confidence: bool = False
    classification_right: str = ""
    classification_left: str = ""
    annotated_image_rgb: Optional[np.ndarray] = None


def calculate_angle(a, b, c) -> float:
    """Angle at vertex b (in degrees) formed by points a-b-c."""
    a, b, c = np.array(a), np.array(b), np.array(c)
    ba = a - b
    bc = c - b
    cosine_angle = np.dot(ba, bc) / (np.linalg.norm(ba) * np.linalg.norm(bc))
    return float(np.degrees(np.arccos(np.clip(cosine_angle, -1.0, 1.0))))


def _draw_dotted_line(img, pt1, pt2, color, thickness=2, gap=10):
    pt1, pt2 = np.array(pt1, dtype=int), np.array(pt2, dtype=int)
    dist = np.linalg.norm(pt2 - pt1)
    num_dots = int(dist / gap)
    for i in range(num_dots + 1):
        t = i / max(num_dots, 1)
        point = (pt1 * (1 - t) + pt2 * t).astype(int)
        cv2.circle(img, tuple(point), thickness, color, -1)


def _classify_deviation(angle: float) -> str:
    low = th.POSTURE_KNEE_ANGLE_THRESHOLDS["normal_min_degrees"]
    high = th.POSTURE_KNEE_ANGLE_THRESHOLDS["normal_max_degrees"]
    deviation = 180 - angle
    if angle < low:
        return f"Varus {abs(round(deviation, 1))} deg"
    if angle > high:
        return f"Valgus {abs(round(deviation, 1))} deg"
    return "Neutral"


def _draw_leg_keypoints(annotated, points_px):
    for i, j in LEG_CONNECTIONS:
        if i in points_px and j in points_px:
            cv2.line(annotated, points_px[i], points_px[j], LEG_COLOR, 3)
    for idx, (x, y) in points_px.items():
        cv2.circle(annotated, (x, y), 6, (0, 0, 0), -1)
        cv2.circle(annotated, (x, y), 4, (0, 255, 255), -1)
        label_pos = (x + 15, y - 10)
        cv2.line(annotated, (x, y), label_pos, (255, 255, 255), 1)
        cv2.putText(annotated, str(idx), label_pos,
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 2, cv2.LINE_AA)


def _annotate_leg_angle(annotated, hip, knee, ankle, angle, is_risk, side_label, classification):
    hip_p, knee_p, ankle_p = tuple(map(int, hip)), tuple(map(int, knee)), tuple(map(int, ankle))
    _draw_dotted_line(annotated, hip_p, ankle_p, (255, 255, 255), thickness=3, gap=12)

    label_color = (0, 0, 255) if is_risk else (0, 200, 0)
    cv2.putText(annotated, f"{side_label} HKA: {angle} deg",
                (knee_p[0] + 40, knee_p[1] - 10),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, label_color, 2, cv2.LINE_AA)
    cv2.putText(annotated, classification,
                (knee_p[0] + 40, knee_p[1] + 15),
                cv2.FONT_HERSHEY_SIMPLEX, 0.55, label_color, 2, cv2.LINE_AA)


def analyze_posture_image(image_bgr: np.ndarray) -> PostureAnalysisResult:
    """
    Run MediaPipe Pose on a lower-limb photo, compute the Hip-Knee-Ankle
    (HKA) angle for each leg, and flag varus/valgus deviation and
    left-right asymmetry against config/thresholds.py cut-offs.

    Never fabricates a result: if mediapipe is missing, no pose is
    detected, or a required joint isn't visible enough, `success=False`
    with a clear `error` is returned instead.
    """
    if not _MEDIAPIPE_AVAILABLE:
        return PostureAnalysisResult(
            success=False,
            error=(
                "The 'mediapipe' package is not installed in this environment. "
                "Install it with 'pip install mediapipe' to use AI Posture "
                f"Detection. Details: {_MP_IMPORT_ERROR}"
            ),
        )

    try:
        mp_pose = mp.solutions.pose
    except AttributeError as exc:
        return PostureAnalysisResult(
            success=False,
            error=(
                "mediapipe's legacy Pose Solutions API is not available in "
                f"this installation. Details: {exc}"
            ),
        )

    image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
    h, w, _ = image_bgr.shape

    with mp_pose.Pose(static_image_mode=True, model_complexity=2) as pose:
        results = pose.process(image_rgb)

    if not results.pose_landmarks:
        return PostureAnalysisResult(
            success=False,
            error="No pose detected. Please upload a clear, full lower-limb photo.",
        )

    lm = results.pose_landmarks.landmark

    def pt_draw(landmark_enum):
        """Used only for the drawn overlay -- stricter threshold."""
        landmark = lm[landmark_enum]
        if landmark.visibility < th.POSTURE_LEG_VISIBILITY_THRESHOLD:
            return None
        return [landmark.x * w, landmark.y * h]

    def pt_core(landmark_enum):
        """Used for the actual angle math -- more lenient threshold."""
        landmark = lm[landmark_enum]
        if landmark.visibility < th.POSTURE_CORE_JOINT_MIN_VISIBILITY:
            return None, landmark.visibility
        return [landmark.x * w, landmark.y * h], landmark.visibility

    keypoint_map = {
        11: mp_pose.PoseLandmark.LEFT_HIP,
        12: mp_pose.PoseLandmark.RIGHT_HIP,
        13: mp_pose.PoseLandmark.LEFT_KNEE,
        14: mp_pose.PoseLandmark.RIGHT_KNEE,
        15: mp_pose.PoseLandmark.LEFT_ANKLE,
        16: mp_pose.PoseLandmark.RIGHT_ANKLE,
    }

    points_px = {}
    for idx, landmark_enum in keypoint_map.items():
        coords = pt_draw(landmark_enum)
        if coords is not None:
            points_px[idx] = (int(coords[0]), int(coords[1]))

    hip_r_raw, vis_hip_r = pt_core(mp_pose.PoseLandmark.RIGHT_HIP)
    knee_r_raw, vis_knee_r = pt_core(mp_pose.PoseLandmark.RIGHT_KNEE)
    ankle_r_raw, vis_ankle_r = pt_core(mp_pose.PoseLandmark.RIGHT_ANKLE)
    hip_l_raw, vis_hip_l = pt_core(mp_pose.PoseLandmark.LEFT_HIP)
    knee_l_raw, vis_knee_l = pt_core(mp_pose.PoseLandmark.LEFT_KNEE)
    ankle_l_raw, vis_ankle_l = pt_core(mp_pose.PoseLandmark.LEFT_ANKLE)

    if None in (hip_r_raw, knee_r_raw, ankle_r_raw, hip_l_raw, knee_l_raw, ankle_l_raw):
        return PostureAnalysisResult(
            success=False,
            error="Hip, knee, or ankle not clearly visible in the image.",
            annotated_image_rgb=cv2.cvtColor(image_bgr.copy(), cv2.COLOR_BGR2RGB),
        )

    low_confidence = min(vis_hip_r, vis_knee_r, vis_ankle_r, vis_hip_l, vis_knee_l, vis_ankle_l) < 0.6

    knee_angle_r = round(calculate_angle(hip_r_raw, knee_r_raw, ankle_r_raw), 1)
    knee_angle_l = round(calculate_angle(hip_l_raw, knee_l_raw, ankle_l_raw), 1)
    asymmetry = round(abs(knee_angle_r - knee_angle_l), 1)

    low = th.POSTURE_KNEE_ANGLE_THRESHOLDS["normal_min_degrees"]
    high = th.POSTURE_KNEE_ANGLE_THRESHOLDS["normal_max_degrees"]
    risk_flag_right = knee_angle_r < low or knee_angle_r > high
    risk_flag_left = knee_angle_l < low or knee_angle_l > high
    risk_flag_asymmetry = asymmetry > th.POSTURE_ASYMMETRY_MAX_DEGREES

    classification_r = _classify_deviation(knee_angle_r)
    classification_l = _classify_deviation(knee_angle_l)

    annotated = image_bgr.copy()
    _draw_leg_keypoints(annotated, points_px)
    _annotate_leg_angle(annotated, hip_r_raw, knee_r_raw, ankle_r_raw, knee_angle_r, risk_flag_right, "R", classification_r)
    _annotate_leg_angle(annotated, hip_l_raw, knee_l_raw, ankle_l_raw, knee_angle_l, risk_flag_left, "L", classification_l)
    annotated_rgb = cv2.cvtColor(annotated, cv2.COLOR_BGR2RGB)

    overall_risk = risk_flag_right or risk_flag_left or risk_flag_asymmetry

    return PostureAnalysisResult(
        success=True,
        knee_angle_right=knee_angle_r,
        knee_angle_left=knee_angle_l,
        angle_asymmetry=asymmetry,
        risk_flag_right=risk_flag_right,
        risk_flag_left=risk_flag_left,
        risk_flag_asymmetry=risk_flag_asymmetry,
        overall_risk=overall_risk,
        low_confidence=low_confidence,
        classification_right=classification_r,
        classification_left=classification_l,
        annotated_image_rgb=annotated_rgb,
    )
