"""
LIME (Local Interpretable Model-agnostic Explanations) for the Software
OA Risk Marker.

Like Grad-CAM and Score-CAM, this is an AI EXPLAINABILITY aid only -- it
shows which image super-pixels most supported the model's prediction,
not independent clinical proof of a lesion or diagnosis.

Requires the `lime` and `scikit-image` packages (see requirements.txt).
If they are not installed, generate_lime_explanation() returns a
LimeResult with success=False and a clear installation message instead
of crashing.
"""

from dataclasses import dataclass
from typing import Optional

import numpy as np

from config import settings
from utils.model_loader import ModelLoadResult
from utils.image_utils import PreparedImage, preprocess_array


@dataclass
class LimeResult:
    success: bool
    positive_only_overlay: Optional[np.ndarray] = None      # uint8 (H, W, 3)
    positive_negative_overlay: Optional[np.ndarray] = None  # uint8 (H, W, 3)
    positive_region_percent: Optional[float] = None
    error: Optional[str] = None


def _make_predict_fn(model_result: ModelLoadResult, target_size):
    """
    Build a LIME-compatible predict_fn: takes a batch of raw uint8/float
    (N, H, W, 3) images -- as LIME's internal perturbation engine
    produces them, which can occasionally be a different size or have an
    alpha channel -- and returns (N, num_classes) probabilities, applying
    the same preprocessing used at inference time.
    """
    import cv2

    backend = model_result.backend
    model = model_result.model

    def predict_fn(images: np.ndarray) -> np.ndarray:
        processed_list = []
        for image in images:
            image = np.asarray(image).astype(np.float32)

            if image.shape[0] != target_size[0] or image.shape[1] != target_size[1]:
                image = cv2.resize(image, target_size)

            if image.shape[-1] == 4:  # drop an alpha channel if present
                image = image[:, :, :3]

            processed_list.append(preprocess_array(image.astype(np.uint8))[0])

        batch = np.asarray(processed_list, dtype=np.float32)

        if backend == "tensorflow":
            preds = model.predict(batch, verbose=0, batch_size=16)
        elif backend == "pytorch":
            import torch
            nchw = np.transpose(batch, (0, 3, 1, 2))
            device = next(model.parameters()).device if hasattr(model, "parameters") else torch.device("cpu")
            with torch.no_grad():
                out = model(torch.from_numpy(nchw).to(device))
            if isinstance(out, (tuple, list)):
                out = out[0]
            preds = out.detach().cpu().numpy()
        else:
            raise ValueError(f"Unsupported backend '{backend}' for LIME.")

        preds = np.asarray(preds)
        if preds.ndim == 1:
            # single sigmoid-style output per image -> build a 2-column distribution
            preds = np.stack([1 - preds, preds], axis=1)
        return preds

    return predict_fn


def generate_lime_explanation(
    model_result: ModelLoadResult,
    prepared_image: PreparedImage,
    predicted_class_index: int,
    num_classes: Optional[int] = None,
    num_samples: Optional[int] = None,
    num_features: Optional[int] = None,
) -> LimeResult:
    """
    Run LIME on the uploaded (resized) X-ray and return two overlays:
      - positive_only_overlay: super-pixels that support the ACTUAL
        predicted class (predicted_class_index) -- always the class the
        rest of the app is displaying, so Grad-CAM/Score-CAM/LIME are
        never explaining three different classes.
      - positive_negative_overlay: green = supports, red = against
    """
    if not model_result.loaded or model_result.model is None:
        return LimeResult(success=False, error=model_result.error or "The G5 model is not loaded.")

    try:
        from lime import lime_image
        from skimage.segmentation import mark_boundaries
    except ImportError as exc:
        return LimeResult(
            success=False,
            error=(
                "The 'lime' and 'scikit-image' packages are required for LIME "
                f"explanations. Install them with 'pip install lime scikit-image'. Details: {exc}"
            ),
        )

    num_classes = num_classes or len(settings.G5_CLASS_LABELS)
    num_samples = num_samples or settings.G5_LIME_NUM_SAMPLES
    num_features = num_features or settings.G5_LIME_NUM_FEATURES

    try:
        predict_fn = _make_predict_fn(model_result, settings.G5_INPUT_SIZE)
        explainer = lime_image.LimeImageExplainer()

        explanation = explainer.explain_instance(
            prepared_image.resized_rgb.astype(np.double),
            predict_fn,
            top_labels=num_classes,  # covers every class (2 for this model), so
            hide_color=0,            # predicted_class_index is always explainable below
            num_samples=num_samples,
        )

        temp_pos, mask_pos = explanation.get_image_and_mask(
            predicted_class_index, positive_only=True, num_features=num_features, hide_rest=False
        )
        temp_pn, mask_pn = explanation.get_image_and_mask(
            predicted_class_index, positive_only=False, negative_only=False,
            num_features=num_features, hide_rest=False,
        )

        temp_pos = np.clip(temp_pos, 0, 255).astype(np.uint8)
        temp_pn = np.clip(temp_pn, 0, 255).astype(np.uint8)

        pos_overlay = np.uint8(np.clip(mark_boundaries(temp_pos / 255.0, mask_pos) * 255, 0, 255))
        pn_overlay = np.uint8(np.clip(mark_boundaries(temp_pn / 255.0, mask_pn) * 255, 0, 255))

        total_pixels = mask_pos.shape[0] * mask_pos.shape[1]
        positive_percent = float(np.sum(mask_pos != 0)) / total_pixels * 100 if total_pixels else 0.0

    except Exception as exc:  # noqa: BLE001
        return LimeResult(
            success=False,
            error=f"LIME explanation generation failed. Details: {exc}",
        )

    return LimeResult(
        success=True,
        positive_only_overlay=pos_overlay,
        positive_negative_overlay=pn_overlay,
        positive_region_percent=positive_percent,
    )
