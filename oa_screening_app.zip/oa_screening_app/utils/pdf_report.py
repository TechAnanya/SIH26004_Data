"""
Professional PDF report generation for both screening pathways, using
ReportLab. Hardware and Software reports are generated independently --
this module never combines or averages results from the two pathways.
"""

import io
import os
from datetime import datetime

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.lib.enums import TA_CENTER
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
    Image as RLImage,
    HRFlowable,
)
from PIL import Image as PILImage

from config.settings import APP_NAME, ORG_NAME, MEDICAL_DISCLAIMER
from config import thresholds as th

PRIMARY = colors.HexColor("#1a5f7a")
ACCENT = colors.HexColor("#57a6c9")
LOW_RISK = colors.HexColor("#2e7d32")
MODERATE_RISK = colors.HexColor("#e65100")
HIGH_RISK = colors.HexColor("#c62828")
LIGHT_BG = colors.HexColor("#f2f7fa")
TEXT_GRAY = colors.HexColor("#444444")


def _styles():
    ss = getSampleStyleSheet()
    ss.add(ParagraphStyle(name="ReportTitle", fontSize=18, textColor=PRIMARY, spaceAfter=2, fontName="Helvetica-Bold"))
    ss.add(ParagraphStyle(name="ReportSubtitle", fontSize=10, textColor=TEXT_GRAY, spaceAfter=10))
    ss.add(ParagraphStyle(name="SectionHeader", fontSize=12, textColor=colors.white, backColor=PRIMARY,
                           fontName="Helvetica-Bold", spaceBefore=10, spaceAfter=6, leftIndent=6,
                           borderPadding=(4, 4, 4, 4)))
    ss.add(ParagraphStyle(name="Body", fontSize=9.5, textColor=TEXT_GRAY, leading=14))
    ss.add(ParagraphStyle(name="Disclaimer", fontSize=8, textColor=colors.white, backColor=colors.HexColor("#5c5c5c"),
                           leading=11, borderPadding=(6, 6, 6, 6)))
    ss.add(ParagraphStyle(name="Small", fontSize=8, textColor=colors.grey))
    return ss


def _section_header(text, styles):
    return Paragraph(text, styles["SectionHeader"])


def _info_table(rows, col_widths=(45 * mm, 45 * mm, 45 * mm, 45 * mm)):
    """rows: list of (label, value, label, value) 4-tuples for a 2-column info grid."""
    data = []
    for row in rows:
        data.append(row)
    t = Table(data, colWidths=col_widths)
    t.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("TEXTCOLOR", (0, 0), (-1, -1), TEXT_GRAY),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTNAME", (2, 0), (2, -1), "Helvetica-Bold"),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("LINEBELOW", (0, 0), (-1, -1), 0.4, colors.HexColor("#dddddd")),
    ]))
    return t


def _header_block(styles, report_title):
    elements = [
        Paragraph(APP_NAME, styles["ReportTitle"]),
        Paragraph(f"{ORG_NAME} &nbsp;|&nbsp; {report_title}", styles["ReportSubtitle"]),
        HRFlowable(width="100%", thickness=1.2, color=PRIMARY, spaceAfter=8),
    ]
    return elements


def _patient_section(patient_info, styles):
    rows = [
        ["Patient ID", str(getattr(patient_info, "patient_id", "")), "Screening Date", str(getattr(patient_info, "screening_date", ""))],
        ["Patient Name", str(getattr(patient_info, "patient_name", "")), "Operator / Worker ID", str(getattr(patient_info, "operator_id", ""))],
        ["Age", str(getattr(patient_info, "age", "")), "Sex", str(getattr(patient_info, "sex", ""))],
        ["Height (cm)", str(getattr(patient_info, "height_cm", "")), "Weight (kg)", str(getattr(patient_info, "weight_kg", ""))],
        ["BMI", f'{getattr(patient_info, "bmi", "")} ({getattr(patient_info, "bmi_category", "")})', "Location", str(getattr(patient_info, "location", ""))],
    ]
    return [_section_header("Patient Information", styles), _info_table(rows), Spacer(1, 6)]


def _history_section(patient_history, styles):
    rows = [
        ["Previous Knee Injury", "Yes" if getattr(patient_history, "previous_knee_injury", False) else "No",
         "Morning Knee Stiffness", "Yes" if getattr(patient_history, "morning_stiffness", False) else "No"],
        ["Knee Pain Score (0-10)", str(getattr(patient_history, "knee_pain_score", "")),
         "Difficulty Climbing Stairs", "Yes" if getattr(patient_history, "stair_difficulty", False) else "No"],
    ]
    return [_section_header("Patient History &amp; Symptom Screening", styles), _info_table(rows), Spacer(1, 6)]


def _risk_color(category: str):
    if category == "Low Risk":
        return LOW_RISK
    if category == "Moderate Risk":
        return MODERATE_RISK
    return HIGH_RISK


def _disclaimer_block(styles):
    return [
        Spacer(1, 10),
        Paragraph("Medical Disclaimer", ParagraphStyle(name="DiscHead", fontSize=9, fontName="Helvetica-Bold", textColor=colors.HexColor("#5c5c5c"))),
        Spacer(1, 2),
        Paragraph(MEDICAL_DISCLAIMER, styles["Disclaimer"]),
    ]


# ----------------------------------------------------------------------
# Hardware OA Screening Report
# ----------------------------------------------------------------------
def generate_hardware_pdf_report(patient_info, patient_history, sensor_readings, risk_result) -> bytes:
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, topMargin=18 * mm, bottomMargin=15 * mm,
                             leftMargin=16 * mm, rightMargin=16 * mm)
    styles = _styles()
    story = []

    story += _header_block(styles, "Hardware OA Screening Report")
    story += _patient_section(patient_info, styles)
    story += _history_section(patient_history, styles)

    story.append(_section_header("Sensor Measurements" + ("  (Demonstration / Manual Input Mode)" if sensor_readings.demo_mode else ""), styles))
    sensor_rows = [
        ["Knee Range of Motion (ROM)", f"{sensor_readings.knee_rom_degrees:.1f} deg",
         "Walking Cadence", f"{sensor_readings.walking_cadence_spm:.1f} steps/min"],
        ["Gait Asymmetry", f"{sensor_readings.gait_asymmetry_percent:.1f}%",
         "Left-Right Pressure Asymmetry", f"{sensor_readings.pressure_asymmetry_percent:.1f}%"],
    ]
    story.append(_info_table(sensor_rows))
    story.append(Spacer(1, 8))

    story.append(_section_header("Rule-Based Risk Assessment Result", styles))
    cat_color = _risk_color(risk_result.category)
    result_table = Table(
        [["Hardware OA Risk Score", "Screening Category"],
         [str(risk_result.score), risk_result.category]],
        colWidths=[90 * mm, 90 * mm],
    )
    result_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), PRIMARY),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("BACKGROUND", (0, 1), (-1, 1), LIGHT_BG),
        ("TEXTCOLOR", (1, 1), (1, 1), cat_color),
        ("FONTNAME", (0, 1), (-1, 1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 11),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#dddddd")),
    ]))
    story.append(result_table)
    story.append(Spacer(1, 4))
    story.append(Paragraph(
        "This is a rule-based / threshold screening score, not a statistically "
        "calibrated clinical probability.", styles["Small"]))
    story.append(Spacer(1, 8))

    story.append(_section_header("Detected Risk Markers &amp; Contributing Factors", styles))
    marker_data = [["Factor", "Status", "Detail"]]
    for m in risk_result.markers:
        marker_data.append([m.factor, m.status, m.detail])
    marker_table = Table(marker_data, colWidths=[45 * mm, 22 * mm, 113 * mm])
    style_cmds = [
        ("BACKGROUND", (0, 0), (-1, 0), PRIMARY),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#dddddd")),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]
    for i, m in enumerate(risk_result.markers, start=1):
        color = LOW_RISK if m.status == "Normal" else (MODERATE_RISK if m.status == "Borderline" else HIGH_RISK)
        style_cmds.append(("TEXTCOLOR", (1, i), (1, i), color))
        style_cmds.append(("FONTNAME", (1, i), (1, i), "Helvetica-Bold"))
    marker_table.setStyle(TableStyle(style_cmds))
    story.append(marker_table)
    story.append(Spacer(1, 8))

    story.append(_section_header("Follow-Up &amp; Preventive Guidance", styles))
    guidance = _hardware_guidance(risk_result.category)
    for line in guidance:
        story.append(Paragraph(f"&bull; {line}", styles["Body"]))

    story += _disclaimer_block(styles)

    doc.build(story)
    return buf.getvalue()


def _hardware_guidance(category: str):
    common = [
        "Maintain a healthy body weight to reduce joint loading.",
        "Engage in low-impact activity (walking, swimming, cycling) as tolerated.",
        "Consider gentle knee-strengthening and flexibility exercises.",
    ]
    if category == "Low Risk":
        return ["No significant hardware-based risk markers were detected at this time."] + common
    if category == "Moderate Risk":
        return [
            "One or more risk markers were detected. Consider a clinical evaluation "
            "if symptoms persist or worsen.",
        ] + common
    return [
        "Multiple significant risk markers were detected. Referral to a qualified "
        "healthcare professional for clinical evaluation is recommended.",
    ] + common


# ----------------------------------------------------------------------
# Software OA Screening Report
# ----------------------------------------------------------------------
def generate_software_pdf_report(
    patient_info,
    patient_history,
    prediction_result,
    xray_image_bytes: bytes = None,
    gradcam_overlay_array=None,
    scorecam_overlay_array=None,
    lime_positive_overlay_array=None,
    lime_positive_negative_overlay_array=None,
) -> bytes:
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, topMargin=18 * mm, bottomMargin=15 * mm,
                             leftMargin=16 * mm, rightMargin=16 * mm)
    styles = _styles()
    story = []

    story += _header_block(styles, "Software OA Screening Report (AI Image Analysis)")
    story += _patient_section(patient_info, styles)
    story += _history_section(patient_history, styles)

    story.append(_section_header("Knee X-ray Image &amp; AI Explainability Visualizations", styles))
    tmp_paths = []
    entries = []  # list of (flowable_path, caption)

    if xray_image_bytes:
        p = _save_temp_image_bytes(xray_image_bytes, "orig")
        tmp_paths.append(p)
        entries.append((p, "Original X-ray"))
    if gradcam_overlay_array is not None:
        p2 = _save_temp_image_array(gradcam_overlay_array, "cam")
        tmp_paths.append(p2)
        entries.append((p2, "Grad-CAM Overlay"))
    if scorecam_overlay_array is not None:
        p3 = _save_temp_image_array(scorecam_overlay_array, "scorecam")
        tmp_paths.append(p3)
        entries.append((p3, "Score-CAM Overlay"))
    if lime_positive_overlay_array is not None:
        p4 = _save_temp_image_array(lime_positive_overlay_array, "lime_pos")
        tmp_paths.append(p4)
        entries.append((p4, "LIME (positive regions)"))
    if lime_positive_negative_overlay_array is not None:
        p5 = _save_temp_image_array(lime_positive_negative_overlay_array, "lime_pn")
        tmp_paths.append(p5)
        entries.append((p5, "LIME (positive + negative)"))

    if entries:
        # Lay out up to 3 images per row so captions stay legible however
        # many explainability outputs (Grad-CAM/Score-CAM/LIME) succeeded.
        row_size = 3 if len(entries) > 2 else len(entries)
        img_size = 55 * mm if len(entries) > 2 else 80 * mm
        for i in range(0, len(entries), row_size):
            chunk = entries[i:i + row_size]
            img_row = [RLImage(path, width=img_size, height=img_size) for path, _ in chunk]
            cap_row = [caption for _, caption in chunk]
            col_width = img_size + 5 * mm
            img_table = Table([img_row], colWidths=[col_width] * len(chunk))
            img_table.setStyle(TableStyle([("ALIGN", (0, 0), (-1, -1), "CENTER")]))
            story.append(img_table)
            cap_table = Table([cap_row], colWidths=[col_width] * len(chunk))
            cap_table.setStyle(TableStyle([
                ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                ("FONTSIZE", (0, 0), (-1, -1), 8),
                ("TEXTCOLOR", (0, 0), (-1, -1), colors.grey),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ]))
            story.append(cap_table)
    story.append(Spacer(1, 8))

    story.append(_section_header("AI Model Prediction Result", styles))
    if not prediction_result or not prediction_result.success:
        err = prediction_result.error if prediction_result else "The G5 model was not available."
        story.append(Paragraph(f"<b>Model prediction unavailable:</b> {err}", styles["Body"]))
    else:
        assess_color = HIGH_RISK if prediction_result.assessment == "ABNORMAL" else LOW_RISK
        result_table = Table(
            [["Joint Problem Detected", "Predicted Class", "Probability"],
             ["YES" if prediction_result.joint_problem_detected else "NO",
              prediction_result.predicted_label,
              f"{prediction_result.positive_class_probability * 100:.1f}%"]],
            colWidths=[60 * mm, 60 * mm, 60 * mm],
        )
        result_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), PRIMARY),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("BACKGROUND", (0, 1), (-1, 1), LIGHT_BG),
            ("TEXTCOLOR", (0, 1), (0, 1), assess_color),
            ("FONTNAME", (0, 1), (-1, 1), "Helvetica-Bold"),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#dddddd")),
            ("TOPPADDING", (0, 0), (-1, -1), 8),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ]))
        story.append(result_table)
        story.append(Spacer(1, 4))
        story.append(Paragraph(
            f"<b>Assessment:</b> {prediction_result.assessment} &nbsp;&nbsp; "
            f"(Class labels and probability are produced directly by the trained G5 model.)",
            styles["Body"]))
        story.append(Spacer(1, 8))
        story.append(Paragraph(
            "Grad-CAM and Score-CAM highlight image regions that most influenced the model's "
            "prediction; LIME shows which super-pixel regions supported (green) or opposed (red) "
            "the predicted class. All three are AI explainability visualizations only, and are NOT "
            "independent clinical proof of a lesion or diagnosis.",
            styles["Small"]))

    story.append(Spacer(1, 8))
    story.append(_section_header("Follow-Up Guidance", styles))
    if prediction_result and prediction_result.success:
        guidance = _software_guidance(prediction_result.assessment)
    else:
        guidance = ["Re-run the screening once a valid G5 model is available, or use the Hardware OA Risk Marker in the meantime."]
    for line in guidance:
        story.append(Paragraph(f"&bull; {line}", styles["Body"]))

    story += _disclaimer_block(styles)

    doc.build(story)

    for p in tmp_paths:
        try:
            os.remove(p)
        except OSError:
            pass

    return buf.getvalue()


def _software_guidance(assessment: str):
    if assessment == "ABNORMAL":
        return [
            "The AI model flagged a possible joint problem / OA-related abnormality. "
            "Referral to a qualified healthcare professional (orthopedician/radiologist) "
            "for confirmation is recommended.",
            "Bring this report and the original X-ray to the consultation.",
        ]
    return [
        "The AI model did not flag a significant abnormality in this X-ray.",
        "Continue routine monitoring; seek clinical evaluation if symptoms are present or worsen.",
    ]


# ----------------------------------------------------------------------
# AI Posture Detection Report
# ----------------------------------------------------------------------
def generate_posture_pdf_report(patient_info, patient_history, posture_result) -> bytes:
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, topMargin=18 * mm, bottomMargin=15 * mm,
                             leftMargin=16 * mm, rightMargin=16 * mm)
    styles = _styles()
    story = []

    story += _header_block(styles, "AI Posture Detection Report (Lower Limb Alignment)")
    story += _patient_section(patient_info, styles)
    story += _history_section(patient_history, styles)

    tmp_path = None
    story.append(_section_header("Annotated Posture Analysis", styles))
    if posture_result.annotated_image_rgb is not None:
        tmp_path = _save_temp_image_array(posture_result.annotated_image_rgb, "posture")
        img_table = Table([[RLImage(tmp_path, width=80 * mm, height=80 * mm)]], colWidths=[190 * mm])
        img_table.setStyle(TableStyle([("ALIGN", (0, 0), (-1, -1), "CENTER")]))
        story.append(img_table)
        story.append(Spacer(1, 4))
        story.append(Paragraph(
            "Hip/knee/ankle landmarks were detected using Google's MediaPipe "
            "pose-estimation model (AI) -- the only AI component of this "
            "pathway. The dotted line shows the mechanical hip-knee-ankle "
            "axis; the labeled angle and Varus/Valgus classification are "
            "computed directly from the detected landmark positions using "
            "plain trigonometry and fixed thresholds.",
            styles["Small"]))
    story.append(Spacer(1, 8))

    story.append(_section_header("Measured Alignment Values", styles))
    if posture_result.low_confidence:
        story.append(Paragraph(
            "<b>Note:</b> some joint points had lower detection confidence "
            "in the source photo -- angles may be less precise.", styles["Body"]))
        story.append(Spacer(1, 4))

    result_rows = [
        ["Right Knee Angle (HKA)", f"{posture_result.knee_angle_right} deg",
         "Left Knee Angle (HKA)", f"{posture_result.knee_angle_left} deg"],
        ["Angle Asymmetry", f"{posture_result.angle_asymmetry} deg",
         "Overall Assessment", "At Risk" if posture_result.overall_risk else "Normal"],
    ]
    story.append(_info_table(result_rows))
    story.append(Spacer(1, 4))
    low = th.POSTURE_KNEE_ANGLE_THRESHOLDS["normal_min_degrees"]
    high = th.POSTURE_KNEE_ANGLE_THRESHOLDS["normal_max_degrees"]
    story.append(Paragraph(
        f"Normal HKA range: {low} deg &ndash; {high} deg &nbsp;|&nbsp; "
        f"Asymmetry threshold: {th.POSTURE_ASYMMETRY_MAX_DEGREES} deg "
        "(plain threshold comparison on an AI-detected measurement, not a "
        "trained OA classifier).", styles["Small"]))
    story.append(Spacer(1, 8))

    story.append(_section_header("Detected Risk Markers", styles))
    marker_data = [
        ["Factor", "Status", "Detail"],
        ["Right Knee Alignment", "Abnormal" if posture_result.risk_flag_right else "Normal", posture_result.classification_right],
        ["Left Knee Alignment", "Abnormal" if posture_result.risk_flag_left else "Normal", posture_result.classification_left],
        ["Left-Right Symmetry", "Abnormal" if posture_result.risk_flag_asymmetry else "Normal", f"{posture_result.angle_asymmetry} deg difference"],
    ]
    marker_table = Table(marker_data, colWidths=[45 * mm, 30 * mm, 105 * mm])
    style_cmds = [
        ("BACKGROUND", (0, 0), (-1, 0), PRIMARY),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#dddddd")),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]
    for i, flag in enumerate(
        [posture_result.risk_flag_right, posture_result.risk_flag_left, posture_result.risk_flag_asymmetry],
        start=1,
    ):
        color = HIGH_RISK if flag else LOW_RISK
        style_cmds.append(("TEXTCOLOR", (1, i), (1, i), color))
        style_cmds.append(("FONTNAME", (1, i), (1, i), "Helvetica-Bold"))
    marker_table.setStyle(TableStyle(style_cmds))
    story.append(marker_table)
    story.append(Spacer(1, 8))

    story.append(_section_header("Follow-Up &amp; Preventive Guidance", styles))
    for line in _posture_guidance(posture_result.overall_risk):
        story.append(Paragraph(f"&bull; {line}", styles["Body"]))

    story += _disclaimer_block(styles)

    doc.build(story)

    if tmp_path:
        try:
            os.remove(tmp_path)
        except OSError:
            pass

    return buf.getvalue()


def _posture_guidance(overall_risk: bool):
    common = [
        "Maintain a healthy body weight to reduce joint loading.",
        "Engage in low-impact activity (walking, swimming, cycling) as tolerated.",
        "Consider gentle knee-strengthening and flexibility exercises.",
    ]
    if overall_risk:
        return [
            "Posture-based alignment indicators (varus/valgus deviation or "
            "left-right asymmetry) were detected. Consider a clinical "
            "evaluation if symptoms persist or worsen.",
        ] + common
    return ["No posture-based alignment risk indicators were detected at this time."] + common


def _save_temp_image_bytes(image_bytes: bytes, tag: str) -> str:
    from config.settings import TEMP_DIR
    path = os.path.join(TEMP_DIR, f"report_{tag}_{datetime.now().strftime('%Y%m%d%H%M%S%f')}.png")
    img = PILImage.open(io.BytesIO(image_bytes)).convert("RGB")
    img.save(path, format="PNG")
    return path


def _save_temp_image_array(array, tag: str) -> str:
    from config.settings import TEMP_DIR
    path = os.path.join(TEMP_DIR, f"report_{tag}_{datetime.now().strftime('%Y%m%d%H%M%S%f')}.png")
    img = PILImage.fromarray(array)
    img.save(path, format="PNG")
    return path
