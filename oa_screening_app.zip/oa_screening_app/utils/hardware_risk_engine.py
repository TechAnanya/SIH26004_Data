"""
Hardware OA Risk Marker -- rule-based / threshold-based assessment engine.

STRICT DESIGN CONSTRAINT: This module contains NO machine learning, deep
learning, artificial intelligence, or trained classification model of any
kind. It only performs plain, transparent, and fully explainable Python
comparisons against the configurable thresholds defined in
config/thresholds.py. Every contributing factor that affects the final
result is enumerated in the returned explanation so a healthcare worker
can see exactly why a patient was scored the way they were.

If a validated clinical scoring formula for a true calibrated probability
is supplied in the future, it can be wired in here to replace / augment
`compute_risk_score()` -- until then, the output is explicitly labelled a
"Hardware OA Risk Score / Screening Category", never a probability.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any

from config.thresholds import (
    KNEE_ROM_THRESHOLDS,
    WALKING_CADENCE_THRESHOLDS,
    GAIT_ASYMMETRY_THRESHOLDS,
    PRESSURE_ASYMMETRY_THRESHOLDS,
    KNEE_PAIN_SCORE_MODERATE,
    KNEE_PAIN_SCORE_SEVERE,
    RISK_WEIGHTS,
    RISK_CATEGORY_THRESHOLDS,
    BMI_OA_RISK_CUTOFF,
    AGE_RISK_CUTOFF,
)


class SensorValidationError(Exception):
    """Raised when a sensor reading is missing or physiologically implausible."""


@dataclass
class SensorReadings:
    knee_rom_degrees: float
    walking_cadence_spm: float
    gait_asymmetry_percent: float
    pressure_asymmetry_percent: float
    demo_mode: bool = False  # True when values were entered manually (no ESP32)


@dataclass
class RiskMarker:
    factor: str
    status: str          # "Normal" | "Borderline" | "Abnormal"
    detail: str
    points: int = 0


@dataclass
class HardwareRiskResult:
    score: int
    category: str          # "Low Risk" | "Moderate Risk" | "High Risk"
    markers: List[RiskMarker] = field(default_factory=list)
    contributing_factors: List[str] = field(default_factory=list)
    demo_mode: bool = False


# ----------------------------------------------------------------------
# Sensor data processing / validation
# ----------------------------------------------------------------------
def process_sensor_data(
    knee_rom_degrees,
    walking_cadence_spm,
    gait_asymmetry_percent,
    pressure_asymmetry_percent,
    demo_mode: bool = False,
) -> SensorReadings:
    """
    Validate and package the four sensor-derived measurements that reach
    the application. Raw accelerometer / gyroscope / pressure signals are
    expected to already have been processed into these four values
    upstream (on the ESP32 firmware or in the acquisition layer) -- this
    function does not receive or expose raw sensor streams.
    """
    required = {
        "Knee Range of Motion (ROM)": knee_rom_degrees,
        "Walking Cadence": walking_cadence_spm,
        "Gait Asymmetry": gait_asymmetry_percent,
        "Left-Right Pressure Asymmetry": pressure_asymmetry_percent,
    }
    missing = [name for name, val in required.items() if val is None or val == ""]
    if missing:
        raise SensorValidationError(
            "Missing sensor measurement(s): " + ", ".join(missing)
        )

    try:
        knee_rom_degrees = float(knee_rom_degrees)
        walking_cadence_spm = float(walking_cadence_spm)
        gait_asymmetry_percent = float(gait_asymmetry_percent)
        pressure_asymmetry_percent = float(pressure_asymmetry_percent)
    except (TypeError, ValueError):
        raise SensorValidationError("Sensor measurements must be numeric.")

    # Plausibility bounds -- reject obviously corrupted / out-of-range
    # sensor data rather than silently scoring nonsense values.
    if not (0 <= knee_rom_degrees <= 180):
        raise SensorValidationError(
            "Knee ROM reading is out of plausible range (0-180 degrees)."
        )
    if not (0 <= walking_cadence_spm <= 200):
        raise SensorValidationError(
            "Walking cadence reading is out of plausible range (0-200 steps/min)."
        )
    if not (0 <= gait_asymmetry_percent <= 100):
        raise SensorValidationError(
            "Gait asymmetry reading is out of plausible range (0-100%)."
        )
    if not (0 <= pressure_asymmetry_percent <= 100):
        raise SensorValidationError(
            "Pressure asymmetry reading is out of plausible range (0-100%)."
        )

    return SensorReadings(
        knee_rom_degrees=knee_rom_degrees,
        walking_cadence_spm=walking_cadence_spm,
        gait_asymmetry_percent=gait_asymmetry_percent,
        pressure_asymmetry_percent=pressure_asymmetry_percent,
        demo_mode=demo_mode,
    )


# ----------------------------------------------------------------------
# Rule-based risk evaluation
# ----------------------------------------------------------------------
def evaluate_hardware_risk(patient_info, patient_history, sensor: SensorReadings) -> HardwareRiskResult:
    """
    Apply the configurable threshold rules to patient info + history +
    sensor readings and return the detected risk markers, an additive
    rule-based score, a final screening category, and a plain-language
    explanation of every contributing factor.

    `patient_info` and `patient_history` may be PatientInfo / PatientHistory
    dataclass instances or any object/dict exposing the same attributes.
    """
    def get(obj, key, default=None):
        if isinstance(obj, dict):
            return obj.get(key, default)
        return getattr(obj, key, default)

    markers: List[RiskMarker] = []
    score = 0

    # --- Age ---
    age = get(patient_info, "age")
    if age is not None and age >= AGE_RISK_CUTOFF:
        pts = RISK_WEIGHTS["age_over_45"]
        score += pts
        markers.append(RiskMarker(
            "Age", "Borderline",
            f"Age {age} is at/above the {AGE_RISK_CUTOFF}-year OA risk reference age.",
            pts,
        ))
    else:
        markers.append(RiskMarker("Age", "Normal", f"Age {age} is below the {AGE_RISK_CUTOFF}-year reference age.", 0))

    # --- BMI ---
    bmi = get(patient_info, "bmi")
    if bmi is not None:
        if bmi >= BMI_OA_RISK_CUTOFF:
            pts = RISK_WEIGHTS["bmi_overweight_or_above"]
            score += pts
            markers.append(RiskMarker(
                "BMI", "Borderline",
                f"BMI {bmi} is at/above the {BMI_OA_RISK_CUTOFF} reference cut-off "
                f"associated with increased joint loading.",
                pts,
            ))
        else:
            markers.append(RiskMarker("BMI", "Normal", f"BMI {bmi} is below the {BMI_OA_RISK_CUTOFF} reference cut-off.", 0))

    # --- Previous knee injury ---
    prev_injury = get(patient_history, "previous_knee_injury")
    if prev_injury:
        pts = RISK_WEIGHTS["previous_knee_injury"]
        score += pts
        markers.append(RiskMarker("Previous Knee Injury", "Borderline", "Patient reports a previous knee injury.", pts))
    else:
        markers.append(RiskMarker("Previous Knee Injury", "Normal", "No previous knee injury reported.", 0))

    # --- Knee pain score ---
    pain = get(patient_history, "knee_pain_score")
    if pain is not None:
        if pain >= KNEE_PAIN_SCORE_SEVERE:
            pts = RISK_WEIGHTS["knee_pain_severe"]
            score += pts
            markers.append(RiskMarker("Knee Pain Score", "Abnormal", f"Pain score {pain}/10 is in the severe range (>= {KNEE_PAIN_SCORE_SEVERE}).", pts))
        elif pain >= KNEE_PAIN_SCORE_MODERATE:
            pts = RISK_WEIGHTS["knee_pain_borderline"]
            score += pts
            markers.append(RiskMarker("Knee Pain Score", "Borderline", f"Pain score {pain}/10 is in the moderate range (>= {KNEE_PAIN_SCORE_MODERATE}).", pts))
        else:
            markers.append(RiskMarker("Knee Pain Score", "Normal", f"Pain score {pain}/10 is mild/none.", 0))

    # --- Morning stiffness ---
    stiffness = get(patient_history, "morning_stiffness")
    if stiffness:
        pts = RISK_WEIGHTS["morning_stiffness"]
        score += pts
        markers.append(RiskMarker("Morning Knee Stiffness", "Borderline", "Patient reports morning knee stiffness.", pts))
    else:
        markers.append(RiskMarker("Morning Knee Stiffness", "Normal", "No morning knee stiffness reported.", 0))

    # --- Stair difficulty ---
    stairs = get(patient_history, "stair_difficulty")
    if stairs:
        pts = RISK_WEIGHTS["stair_difficulty"]
        score += pts
        markers.append(RiskMarker("Difficulty Climbing Stairs", "Borderline", "Patient reports difficulty climbing stairs.", pts))
    else:
        markers.append(RiskMarker("Difficulty Climbing Stairs", "Normal", "No difficulty climbing stairs reported.", 0))

    # --- Knee ROM ---
    rom = sensor.knee_rom_degrees
    if rom < KNEE_ROM_THRESHOLDS["borderline_min_degrees"]:
        pts = RISK_WEIGHTS["knee_rom_abnormal"]
        score += pts
        markers.append(RiskMarker("Knee Range of Motion (ROM)", "Abnormal", f"{rom:.1f} deg is below the borderline reference of {KNEE_ROM_THRESHOLDS['borderline_min_degrees']} deg.", pts))
    elif rom < KNEE_ROM_THRESHOLDS["normal_min_degrees"]:
        pts = RISK_WEIGHTS["knee_rom_borderline"]
        score += pts
        markers.append(RiskMarker("Knee Range of Motion (ROM)", "Borderline", f"{rom:.1f} deg is below the normal reference of {KNEE_ROM_THRESHOLDS['normal_min_degrees']} deg.", pts))
    else:
        markers.append(RiskMarker("Knee Range of Motion (ROM)", "Normal", f"{rom:.1f} deg is within the normal reference range.", 0))

    # --- Walking cadence ---
    cad = sensor.walking_cadence_spm
    if cad < WALKING_CADENCE_THRESHOLDS["borderline_min_spm"]:
        pts = RISK_WEIGHTS["cadence_abnormal"]
        score += pts
        markers.append(RiskMarker("Walking Cadence", "Abnormal", f"{cad:.1f} steps/min is below the borderline reference of {WALKING_CADENCE_THRESHOLDS['borderline_min_spm']} steps/min.", pts))
    elif cad < WALKING_CADENCE_THRESHOLDS["normal_min_spm"]:
        pts = RISK_WEIGHTS["cadence_borderline"]
        score += pts
        markers.append(RiskMarker("Walking Cadence", "Borderline", f"{cad:.1f} steps/min is below the normal reference of {WALKING_CADENCE_THRESHOLDS['normal_min_spm']} steps/min.", pts))
    else:
        markers.append(RiskMarker("Walking Cadence", "Normal", f"{cad:.1f} steps/min is within the normal reference range.", 0))

    # --- Gait asymmetry ---
    gait = sensor.gait_asymmetry_percent
    if gait > GAIT_ASYMMETRY_THRESHOLDS["borderline_max_percent"]:
        pts = RISK_WEIGHTS["gait_asymmetry_abnormal"]
        score += pts
        markers.append(RiskMarker("Gait Asymmetry", "Abnormal", f"{gait:.1f}% exceeds the borderline reference of {GAIT_ASYMMETRY_THRESHOLDS['borderline_max_percent']}%.", pts))
    elif gait > GAIT_ASYMMETRY_THRESHOLDS["normal_max_percent"]:
        pts = RISK_WEIGHTS["gait_asymmetry_borderline"]
        score += pts
        markers.append(RiskMarker("Gait Asymmetry", "Borderline", f"{gait:.1f}% exceeds the normal reference of {GAIT_ASYMMETRY_THRESHOLDS['normal_max_percent']}%.", pts))
    else:
        markers.append(RiskMarker("Gait Asymmetry", "Normal", f"{gait:.1f}% is within the normal reference range.", 0))

    # --- Pressure asymmetry ---
    press = sensor.pressure_asymmetry_percent
    if press > PRESSURE_ASYMMETRY_THRESHOLDS["borderline_max_percent"]:
        pts = RISK_WEIGHTS["pressure_asymmetry_abnormal"]
        score += pts
        markers.append(RiskMarker("Left-Right Pressure Asymmetry", "Abnormal", f"{press:.1f}% exceeds the borderline reference of {PRESSURE_ASYMMETRY_THRESHOLDS['borderline_max_percent']}%.", pts))
    elif press > PRESSURE_ASYMMETRY_THRESHOLDS["normal_max_percent"]:
        pts = RISK_WEIGHTS["pressure_asymmetry_borderline"]
        score += pts
        markers.append(RiskMarker("Left-Right Pressure Asymmetry", "Borderline", f"{press:.1f}% exceeds the normal reference of {PRESSURE_ASYMMETRY_THRESHOLDS['normal_max_percent']}%.", pts))
    else:
        markers.append(RiskMarker("Left-Right Pressure Asymmetry", "Normal", f"{press:.1f}% is within the normal reference range.", 0))

    # --- Final category ---
    if score <= RISK_CATEGORY_THRESHOLDS["low_max"]:
        category = "Low Risk"
    elif score <= RISK_CATEGORY_THRESHOLDS["moderate_max"]:
        category = "Moderate Risk"
    else:
        category = "High Risk"

    contributing = [
        f"{m.factor}: {m.detail}" for m in markers if m.status != "Normal"
    ]
    if not contributing:
        contributing = ["No individual risk markers crossed the configured thresholds."]

    return HardwareRiskResult(
        score=score,
        category=category,
        markers=markers,
        contributing_factors=contributing,
        demo_mode=sensor.demo_mode,
    )
