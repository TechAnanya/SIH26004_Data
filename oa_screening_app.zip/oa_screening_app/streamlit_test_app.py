"""
Minimal standalone Streamlit test app for the G5 model: upload an image,
get a prediction (Normal / Osteoarthritis + probability) and a Grad-CAM
overlay. No patient forms, no PDF report, no hardware pathway -- just
the model, isolated, so you can confirm it works before it goes back
into the full screening app.

Run with:
    streamlit run streamlit_test_app.py

Requires ALL of these (the .h5 was saved with TF 2.15's legacy Keras 2
engine, so tf-keras is required, not optional):
    pip install streamlit tensorflow tf-keras numpy opencv-python pillow
"""

import os

# MUST be set before the first `import tensorflow` -- forces TensorFlow
# to use its bundled legacy Keras 2 engine, which is what the model was
# actually saved with (TF 2.15). Without this (AND without the tf-keras
# package that makes it possible), loading final_model.h5 fails with a
# DepthwiseConv2D 'groups' error or an "Invalid Functional model
# configuration ... loops or disconnected nodes" error, because Keras 3
# (the current TensorFlow default) serializes/reconstructs the
# Functional graph differently than Keras 2 did.
os.environ.setdefault("TF_USE_LEGACY_KERAS", "1")

import numpy as np
import cv2
from PIL import Image
import streamlit as st

CLASS_NAMES = ["Normal", "Osteoarthritis"]   # matches train_ds_raw.class_names order
POSITIVE_CLASS_INDEX = 1                      # "Osteoarthritis"
IMG_SIZE = (224, 224)
BASE_LAYER_NAME = "efficientnetb0"            # nested backbone layer name
CONV_LAYER_SUBSTRING = "top_conv"             # target Grad-CAM layer
DEFAULT_MODEL_PATH = "final_model.h5"


# ----------------------------------------------------------------------
# Environment check -- run BEFORE anything touches tf.keras, so the
# error message is specific and actionable instead of a vague failure
# buried inside model loading.
# ----------------------------------------------------------------------
def check_environment():
    """
    Returns (ok: bool, message: str). Checks, in order:
      1. Is TensorFlow installed at all?
      2. Since TF_USE_LEGACY_KERAS=1 is set above, is the 'tf-keras'
         package (which that flag requires) installed? If not,
         tf.keras.* becomes completely unusable and raises a generic
         "Keras cannot be imported" error the first time it's touched.
    """
    try:
        import tensorflow as tf  # noqa: F401
    except ImportError as exc:
        return False, (
            "TensorFlow is not installed. Install it with:\n\n"
            "    pip install tensorflow tf-keras\n\n"
            f"Details: {exc}"
        )

    try:
        import tf_keras  # noqa: F401
    except ImportError:
        return False, (
            "This model needs TensorFlow's legacy Keras 2 engine to load "
            "correctly (it was saved with TF 2.15), which requires the "
            "'tf-keras' package. It is NOT installed yet. Install it with:\n\n"
            "    pip install tf-keras\n\n"
            "then restart this app (stop it and run 'streamlit run "
            "streamlit_test_app.py' again)."
        )

    return True, ""


# ----------------------------------------------------------------------
# Model loading (cached so it only happens once per session)
# ----------------------------------------------------------------------
@st.cache_resource(show_spinner=False)
def load_model(model_path: str):
    import tensorflow as tf

    try:
        model = tf.keras.models.load_model(model_path, compile=False)
    except (TypeError, ValueError) as exc:
        if "DepthwiseConv2D" in str(exc) and "groups" in str(exc):
            class _CompatDepthwiseConv2D(tf.keras.layers.DepthwiseConv2D):
                def __init__(self, *args, **kwargs):
                    kwargs.pop("groups", None)
                    super().__init__(*args, **kwargs)

            model = tf.keras.models.load_model(
                model_path, compile=False,
                custom_objects={"DepthwiseConv2D": _CompatDepthwiseConv2D},
            )
        else:
            raise
    return model


def load_and_prepare_image(file_obj):
    """Raw 0-255 float array -- matches the notebook's preprocess_input,
    which is an identity function for Keras's EfficientNet."""
    img = Image.open(file_obj).convert("RGB").resize(IMG_SIZE, Image.BILINEAR)
    arr = np.array(img, dtype=np.uint8)                        # (H, W, 3) for display
    batched = np.expand_dims(arr.astype(np.float32), axis=0)   # (1, H, W, 3)
    return arr, batched


def predict(model, batched_input):
    preds = model.predict(batched_input, verbose=0)[0]   # softmax probs, shape (2,)
    pred_idx = int(np.argmax(preds))
    return pred_idx, preds


def get_grad_cam(model, batched_input, target_class_idx: int):
    import tensorflow as tf

    base_model_inner = model.get_layer(BASE_LAYER_NAME)
    conv_layer_name = [l.name for l in base_model_inner.layers if CONV_LAYER_SUBSTRING in l.name][-1]

    grad_model = tf.keras.models.Model(
        base_model_inner.inputs,
        [base_model_inner.get_layer(conv_layer_name).output, base_model_inner.output],
    )

    base_idx = model.layers.index(base_model_inner)
    head_layers = model.layers[base_idx + 1:]

    tf_input = tf.convert_to_tensor(batched_input, dtype=tf.float32)

    with tf.GradientTape() as tape:
        conv_outputs, base_output = grad_model(tf_input)
        x = base_output
        for layer in head_layers:
            x = layer(x)
        loss = x[:, target_class_idx]

    grads = tape.gradient(loss, conv_outputs)
    pooled_grads = tf.reduce_mean(grads, axis=(0, 1, 2))
    conv_outputs = conv_outputs[0]
    heatmap = conv_outputs @ pooled_grads[..., tf.newaxis]
    heatmap = tf.squeeze(heatmap)
    heatmap = tf.maximum(heatmap, 0) / (tf.math.reduce_max(heatmap) + 1e-8)
    return heatmap.numpy()


def overlay_heatmap(orig_rgb: np.ndarray, heatmap: np.ndarray) -> np.ndarray:
    h, w = orig_rgb.shape[:2]
    heatmap_resized = cv2.resize(heatmap, (w, h))
    heatmap_uint8 = np.uint8(255 * heatmap_resized)
    heatmap_color = cv2.applyColorMap(heatmap_uint8, cv2.COLORMAP_JET)
    heatmap_color = cv2.cvtColor(heatmap_color, cv2.COLOR_BGR2RGB)
    overlay = cv2.addWeighted(orig_rgb, 0.6, heatmap_color, 0.4, 0)
    return overlay


# ----------------------------------------------------------------------
# Streamlit UI
# ----------------------------------------------------------------------
st.set_page_config(page_title="G5 Model Test", layout="centered")

st.title("G5 Model Test — Predict + Grad-CAM")
st.caption("Minimal test app: upload a knee X-ray, get a prediction and a Grad-CAM overlay.")

env_ok, env_message = check_environment()
if not env_ok:
    st.error(f"Setup issue:\n\n{env_message}")
    st.stop()

model_path = st.text_input("Path to the .h5 model file", value=DEFAULT_MODEL_PATH)

uploaded = st.file_uploader("Upload a knee X-ray image", type=["jpg", "jpeg", "png"])

if uploaded is not None:
    st.image(uploaded, caption="Uploaded X-ray", width=300)

    if st.button("Run Prediction + Grad-CAM", use_container_width=True):
        progress = st.progress(0, text="Starting...")

        if not os.path.exists(model_path):
            progress.empty()
            st.error(f"Model file not found at: {model_path}")
            st.stop()

        progress.progress(20, text="Loading model (20%)...")
        try:
            model = load_model(model_path)
        except Exception as exc:
            progress.empty()
            load_model.clear()  # don't cache a failed load -- retry fresh next click
            st.error(f"Model could not be loaded: {exc}")
            st.stop()

        progress.progress(50, text="Preprocessing image (50%)...")
        orig_rgb, batched = load_and_prepare_image(uploaded)

        progress.progress(70, text="Running prediction (70%)...")
        try:
            pred_idx, probs = predict(model, batched)
        except Exception as exc:
            progress.empty()
            st.error(f"Prediction failed: {exc}")
            st.stop()

        pred_label = CLASS_NAMES[pred_idx]
        pred_confidence = float(probs[pred_idx])
        oa_probability = float(probs[POSITIVE_CLASS_INDEX])
        assessment = "ABNORMAL" if oa_probability >= 0.5 else "NORMAL"

        progress.progress(90, text="Generating Grad-CAM (90%)...")
        try:
            heatmap = get_grad_cam(model, batched, pred_idx)
            overlay = overlay_heatmap(orig_rgb, heatmap)
            gradcam_ok = True
            gradcam_error = None
        except Exception as exc:
            gradcam_ok = False
            gradcam_error = str(exc)
            overlay = None

        progress.progress(100, text="Done (100%)")
        progress.empty()

        st.markdown("### Result")
        c1, c2, c3 = st.columns(3)
        c1.metric("Predicted Class", pred_label)
        c2.metric("Confidence", f"{pred_confidence:.1%}")
        c3.metric("Assessment", assessment)

        st.markdown(f"**Osteoarthritis probability:** {oa_probability:.1%}")

        st.markdown("### Grad-CAM")
        if gradcam_ok:
            gc1, gc2 = st.columns(2)
            with gc1:
                st.image(orig_rgb, caption="Original (resized)", use_container_width=True)
            with gc2:
                st.image(overlay, caption="Grad-CAM Heatmap Overlay", use_container_width=True)
        else:
            st.warning(f"Grad-CAM could not be generated: {gradcam_error}")
else:
    st.info("Upload an X-ray image above to get started.")
