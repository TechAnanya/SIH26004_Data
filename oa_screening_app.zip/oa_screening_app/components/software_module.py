"""
Streamlit component: Software OA Risk Marker pathway.

X-ray upload -> validation -> preprocessing -> G5 model inference ->
probability -> Grad-CAM -> Score-CAM -> LIME -> result display. This is
the ONLY AI/deep learning pathway in the application.
"""

import streamlit as st

from config import settings
from utils.image_utils import validate_uploaded_file, load_and_preprocess_image, ImageValidationError
from utils.model_loader import load_image_model
from utils.predictor import predict_image
from utils.gradcam import generate_gradcam
from utils.scorecam import generate_scorecam
from utils.lime_explain import generate_lime_explanation
from utils.heatmap_utils import get_high_activation_regions
from utils.pdf_report import generate_software_pdf_report
from utils.ui_helpers import card_open, card_close, risk_banner, metric_card


@st.cache_resource(show_spinner=False)
def _cached_load_model(model_path: str, backend: str):
    """
    Load the G5 model once per Streamlit session/process and reuse it on
    every subsequent screening, instead of re-reading the .h5 file from
    disk on every button click. Cached on (model_path, backend), so
    changing either (e.g. via the Settings page / env vars) loads fresh.
    """
    return load_image_model(model_path=model_path, backend=backend)


def render_software_module(patient_info, patient_history):
    card_open("Software OA Risk Marker — Knee X-ray Analysis")
    st.caption(
        "Upload a knee X-ray image (JPG, JPEG, or PNG). The image will be analyzed by the "
        "trained G5 deep-learning model to screen for joint problems / OA-related abnormalities, "
        "with Grad-CAM, Score-CAM, and LIME explainability visualizations."
    )

    with st.expander("Precautions Before Screening", expanded=False):
        st.markdown(
            "- Upload a **clear, correctly oriented, unobstructed** knee X-ray (the same view the "
            "model was trained on) — cropped, rotated, or heavily compressed images reduce prediction "
            "reliability.\n"
            "- Remove or redact any **patient-identifying overlay** burned into the image if privacy "
            "is a concern; this app does not store the image beyond the session.\n"
            "- The AI output (probability, Grad-CAM / Score-CAM / LIME) is a **decision-support aid, "
            "not a radiologic diagnosis** — an abnormal finding here should be confirmed by a "
            "qualified radiologist / orthopedician before any clinical decision.\n"
            "- Do **not** rely on this tool for urgent or emergency symptoms (e.g. suspected fracture, "
            "sudden severe pain) — seek immediate medical care instead."
        )

    uploaded = st.file_uploader("Drag and drop a knee X-ray image here", type=["jpg", "jpeg", "png"], key="sw_uploader")

    with st.expander("Model configuration (advanced)"):
        st.write(f"**Configured model path:** `{settings.G5_MODEL_PATH}`")
        st.write(f"**Backend:** `{settings.G5_MODEL_BACKEND}`")
        st.write(f"**Preprocessing mode:** `{settings.G5_PREPROCESS_MODE}`")
        st.write(f"**Class labels:** {settings.G5_CLASS_LABELS}")
        st.write(f"**Grad-CAM / Score-CAM base layer:** `{settings.G5_GRADCAM_BASE_LAYER_NAME or '(none / flat model)'}`")
        st.write(f"**Grad-CAM / Score-CAM target layer:** `{settings.G5_GRADCAM_TARGET_LAYER or '(not set)'}`")
        st.write(f"**Score-CAM channels:** {settings.G5_SCORECAM_MAX_CHANNELS}")
        st.write(f"**LIME samples / features:** {settings.G5_LIME_NUM_SAMPLES} / {settings.G5_LIME_NUM_FEATURES}")

    card_close()

    if uploaded is None:
        return None

    file_bytes = uploaded.getvalue()

    try:
        validate_uploaded_file(uploaded.name, file_bytes)
    except ImageValidationError as e:
        st.error(f"Error: {e}")
        return None

    card_open("Uploaded X-ray Preview")
    st.image(file_bytes, caption="Uploaded Knee X-ray", width=320)
    card_close()

    run = st.button("Run Software OA Risk Assessment", key="sw_run_btn", use_container_width=True)
    if not run:
        return None

    progress = st.progress(0, text="Starting...")

    try:
        progress.progress(10, text="Validating and preprocessing X-ray (10%)...")
        prepared = load_and_preprocess_image(file_bytes)
    except ImageValidationError as e:
        progress.empty()
        st.error(f"{e}")
        return None

    progress.progress(20, text="Loading G5 model (20%)...")
    model_result = _cached_load_model(settings.G5_MODEL_PATH, settings.G5_MODEL_BACKEND)

    if not model_result.loaded:
        # Don't let a failed load result stick around in the cache -- if
        # the model file gets fixed/added, the very next click should
        # retry from disk instead of replaying the same cached error.
        _cached_load_model.clear()
        progress.empty()
        st.error(f"Model not available: {model_result.error}")
        pdf_bytes = generate_software_pdf_report(patient_info, patient_history, None, xray_image_bytes=file_bytes)
        st.download_button(
            "Download Report (Model Unavailable)",
            data=pdf_bytes,
            file_name=f"software_oa_report_{patient_info.patient_id}.pdf",
            mime="application/pdf",
        )
        return None

    progress.progress(35, text="Running G5 model inference (35%)...")
    prediction = predict_image(model_result, prepared)

    if not prediction.success:
        progress.empty()
        st.error(f"Prediction failed: {prediction.error}")
        pdf_bytes = generate_software_pdf_report(patient_info, patient_history, prediction, xray_image_bytes=file_bytes)
        st.download_button(
            "Download Report (Prediction Failed)",
            data=pdf_bytes,
            file_name=f"software_oa_report_{patient_info.patient_id}.pdf",
            mime="application/pdf",
        )
        return None

    progress.progress(50, text="Generating Grad-CAM (50%)...")
    gradcam_result = generate_gradcam(model_result, prepared, prediction.predicted_index)

    high_activation = None
    if gradcam_result.success:
        try:
            highlighted, mask_rgb, threshold, region_count = get_high_activation_regions(
                gradcam_result.heatmap, prepared.resized_rgb, percentile=settings.G5_HIGH_ACTIVATION_PERCENTILE
            )
            high_activation = {
                "highlighted": highlighted, "mask": mask_rgb,
                "threshold": threshold, "region_count": region_count,
            }
        except Exception:
            high_activation = None  # purely a bonus visual -- never blocks the main result

    progress.progress(70, text=f"Generating Score-CAM using {settings.G5_SCORECAM_MAX_CHANNELS} channels (70%)...")
    scorecam_result = generate_scorecam(model_result, prepared, prediction.predicted_index)

    progress.progress(90, text=f"Generating LIME explanation using {settings.G5_LIME_NUM_SAMPLES} samples (90%)...")
    lime_result = generate_lime_explanation(model_result, prepared, prediction.predicted_index)

    progress.progress(100, text="Done (100%)")
    progress.empty()

    _render_software_result(prediction, prepared, gradcam_result, scorecam_result, lime_result, high_activation)

    pdf_bytes = generate_software_pdf_report(
        patient_info, patient_history, prediction,
        xray_image_bytes=file_bytes,
        gradcam_overlay_array=gradcam_result.overlay_rgb if gradcam_result.success else None,
        scorecam_overlay_array=scorecam_result.overlay_rgb if scorecam_result.success else None,
        lime_positive_overlay_array=lime_result.positive_only_overlay if lime_result.success else None,
        lime_positive_negative_overlay_array=lime_result.positive_negative_overlay if lime_result.success else None,
    )
    st.download_button(
        "Download Software OA Screening Report (PDF)",
        data=pdf_bytes,
        file_name=f"software_oa_report_{patient_info.patient_id}.pdf",
        mime="application/pdf",
        use_container_width=True,
    )

    return {"prediction": prediction, "gradcam": gradcam_result, "scorecam": scorecam_result, "lime": lime_result}


def _render_software_result(prediction, prepared, gradcam_result, scorecam_result, lime_result, high_activation):
    card_open("Software OA Risk Assessment Result (AI Model)")

    category = "High Risk" if prediction.assessment == "ABNORMAL" else "Low Risk"
    risk_banner(
        f"{prediction.positive_class_probability * 100:.1f}%",
        category,
        subtitle=f"OA Probability — Assessment: {prediction.assessment}",
    )

    c1, c2 = st.columns(2)
    with c1:
        metric_card("YES" if prediction.joint_problem_detected else "NO", "Joint Problem Detected")
    with c2:
        metric_card(prediction.predicted_label, "Predicted Class (G5 model)")

    prob_cols = st.columns(len(prediction.probabilities))
    labels = settings.G5_CLASS_LABELS if len(settings.G5_CLASS_LABELS) == len(prediction.probabilities) else range(len(prediction.probabilities))
    for col, label, prob in zip(prob_cols, labels, prediction.probabilities):
        with col:
            st.metric(str(label), f"{prob * 100:.2f}%")
            st.progress(float(prob))

    st.caption(
        "Class labels and probability values are produced directly by the trained G5 model "
        "and its configured output classes (config/settings.py: G5_CLASS_LABELS) — they are "
        "not invented or hard-coded by this application."
    )

    # ------------------------------------------------------------------
    # Grad-CAM
    # ------------------------------------------------------------------
    st.markdown("#### Grad-CAM Explanation")
    st.caption("Identifies spatial regions in the convolutional feature representation associated with the predicted class.")
    if gradcam_result.success:
        gc1, gc2, gc3 = st.columns(3)
        with gc1:
            st.image(prepared.resized_rgb, caption="Original X-ray (resized)", use_container_width=True)
        with gc2:
            st.image(gradcam_result.overlay_rgb, caption="Grad-CAM Overlay", use_container_width=True)
        with gc3:
            if high_activation:
                st.image(high_activation["highlighted"], caption="High-Activation Regions", use_container_width=True)
            else:
                st.info("High-activation region boxes unavailable.")

        if high_activation:
            with st.expander("View detailed Grad-CAM activation mask"):
                st.image(high_activation["mask"], caption="Top activation region mask", use_container_width=True)
            hstat1, hstat2 = st.columns(2)
            with hstat1:
                st.metric("Mean Grad-CAM Activation", f"{gradcam_result.heatmap.mean():.3f}")
            with hstat2:
                st.metric("Detected High-Activation Regions", str(high_activation["region_count"]))
    else:
        st.warning(f"Grad-CAM could not be generated: {gradcam_result.error}")

    # ------------------------------------------------------------------
    # Score-CAM
    # ------------------------------------------------------------------
    st.markdown("#### Score-CAM Explanation")
    st.caption("Weights the backbone's activation maps by how much each one alone contributes to the predicted class score.")
    if scorecam_result.success:
        sc1, sc2, sc3 = st.columns(3)
        with sc1:
            st.image(prepared.resized_rgb, caption="Original X-ray (resized)", use_container_width=True)
        with sc2:
            st.image(scorecam_result.overlay_rgb, caption="Score-CAM Overlay", use_container_width=True)
        with sc3:
            st.metric("Mean Score-CAM Activation", f"{scorecam_result.heatmap.mean():.3f}")
    else:
        st.warning(f"Score-CAM could not be generated: {scorecam_result.error}")

    # ------------------------------------------------------------------
    # LIME
    # ------------------------------------------------------------------
    st.markdown("#### LIME Explanation")
    st.caption("Perturbs image super-pixels and measures their effect on the model's output for the predicted class.")
    if lime_result.success:
        lc1, lc2, lc3 = st.columns(3)
        with lc1:
            st.image(prepared.resized_rgb, caption="Original X-ray (resized)", use_container_width=True)
        with lc2:
            st.image(lime_result.positive_only_overlay, caption="LIME (positive regions)", use_container_width=True)
        with lc3:
            st.image(lime_result.positive_negative_overlay, caption="LIME (positive + negative)", use_container_width=True)
        if lime_result.positive_region_percent is not None:
            st.metric("LIME Positive Region", f"{lime_result.positive_region_percent:.2f}%")
    else:
        st.warning(f"LIME could not be generated: {lime_result.error}")

    st.info(
        "Grad-CAM, Score-CAM, and LIME are AI explainability aids showing which image regions "
        "influenced the model's prediction. None of them are independent clinical proof of a "
        "lesion or diagnosis."
    )

    card_close()
