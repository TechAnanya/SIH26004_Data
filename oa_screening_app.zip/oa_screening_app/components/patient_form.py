"""
Streamlit component: Basic Patient Information + Patient History /
Symptom Screening forms.
"""

from datetime import date

import streamlit as st

from utils.patient_utils import (
    PatientInfo,
    PatientHistory,
    calculate_bmi,
    classify_bmi,
    validate_patient_info,
    validate_patient_history,
    ValidationError,
)
from utils.ui_helpers import card_open, card_close, metric_card


def render_patient_info_form():
    card_open("Basic Patient Information")

    c1, c2, c3 = st.columns(3)
    with c1:
        patient_id = st.text_input("Patient ID", key="pi_patient_id", placeholder="e.g. OA-2026-0001")
        age = st.number_input("Age", key="pi_age", min_value=1, max_value=129, value=45, step=1)
    with c2:
        patient_name = st.text_input("Patient Name", key="pi_patient_name", placeholder="Full name")
        sex = st.selectbox("Sex", ["Male", "Female", "Other"], key="pi_sex")
    with c3:
        operator_id = st.text_input("Healthcare Worker / Operator ID", key="pi_operator_id", placeholder="e.g. HW-014")
        screening_date = st.date_input("Screening Date", key="pi_screening_date", value=date.today())

    c4, c5, c6 = st.columns(3)
    with c4:
        height_cm = st.number_input("Height (cm)", key="pi_height", min_value=0.0, max_value=250.0, value=165.0, step=0.5)
    with c5:
        weight_kg = st.number_input("Weight (kg)", key="pi_weight", min_value=0.0, max_value=400.0, value=65.0, step=0.5)
    with c6:
        location = st.text_input("Location", key="pi_location", placeholder="e.g. Rural Health Camp - Sector 4")

    bmi_val, bmi_cat = None, None
    try:
        bmi_val = calculate_bmi(height_cm, weight_kg)
        bmi_cat = classify_bmi(bmi_val)
        st.markdown("&nbsp;", unsafe_allow_html=True)
        mc1, mc2 = st.columns(2)
        with mc1:
            metric_card(f"{bmi_val}", "Calculated BMI")
        with mc2:
            metric_card(bmi_cat, "BMI Category")
    except ValidationError:
        st.info("Enter valid height and weight to calculate BMI automatically.")

    card_close()

    return {
        "patient_id": patient_id,
        "patient_name": patient_name,
        "age": age,
        "sex": sex,
        "height_cm": height_cm,
        "weight_kg": weight_kg,
        "location": location,
        "screening_date": screening_date,
        "operator_id": operator_id,
        "bmi": bmi_val,
        "bmi_category": bmi_cat,
    }


def render_patient_history_form():
    card_open("Patient History &amp; Symptom Screening")

    c1, c2 = st.columns(2)
    with c1:
        previous_knee_injury = st.radio("Previous Knee Injury", ["No", "Yes"], key="ph_prev_injury", horizontal=True) == "Yes"
        morning_stiffness = st.radio("Morning Knee Stiffness", ["No", "Yes"], key="ph_stiffness", horizontal=True) == "Yes"
    with c2:
        stair_difficulty = st.radio("Difficulty Climbing Stairs", ["No", "Yes"], key="ph_stairs", horizontal=True) == "Yes"
        knee_pain_score = st.slider("Knee Pain Score (0 = none, 10 = worst)", 0, 10, 2, key="ph_pain")

    card_close()

    return {
        "previous_knee_injury": previous_knee_injury,
        "knee_pain_score": knee_pain_score,
        "morning_stiffness": morning_stiffness,
        "stair_difficulty": stair_difficulty,
    }


def build_patient_info_object(data: dict):
    errors = validate_patient_info(
        data["patient_id"], data["patient_name"], data["age"], data["sex"],
        data["height_cm"], data["weight_kg"], data["location"], data["operator_id"],
    )
    if errors:
        return None, errors

    bmi = calculate_bmi(data["height_cm"], data["weight_kg"])
    bmi_cat = classify_bmi(bmi)

    info = PatientInfo(
        patient_id=data["patient_id"].strip(),
        patient_name=data["patient_name"].strip(),
        age=int(data["age"]),
        sex=data["sex"],
        height_cm=float(data["height_cm"]),
        weight_kg=float(data["weight_kg"]),
        location=data["location"].strip(),
        screening_date=data["screening_date"],
        operator_id=data["operator_id"].strip(),
        bmi=bmi,
        bmi_category=bmi_cat,
    )
    return info, []


def build_patient_history_object(data: dict):
    errors = validate_patient_history(
        data["previous_knee_injury"], data["knee_pain_score"],
        data["morning_stiffness"], data["stair_difficulty"],
    )
    if errors:
        return None, errors

    history = PatientHistory(
        previous_knee_injury=bool(data["previous_knee_injury"]),
        knee_pain_score=int(data["knee_pain_score"]),
        morning_stiffness=bool(data["morning_stiffness"]),
        stair_difficulty=bool(data["stair_difficulty"]),
    )
    return history, []
