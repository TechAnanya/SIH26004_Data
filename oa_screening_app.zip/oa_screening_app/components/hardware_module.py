"""
Streamlit component: Hardware OA Risk Marker pathway.

Sensor input (live ESP32 or demo/manual), rule-based evaluation, and
result display. Contains NO machine learning / AI -- see
utils/hardware_risk_engine.py for the underlying rule engine.
"""

import streamlit as st

from utils.hardware_risk_engine import (
    process_sensor_data,
    evaluate_hardware_risk,
    SensorValidationError,
)
from utils.pdf_report import generate_hardware_pdf_report
from utils.ui_helpers import card_open, card_close, status_badge, risk_banner, metric_card, demo_ribbon


def render_hardware_module(patient_info, patient_history):
    card_open("Hardware OA Risk Marker — Sensor Input")

    with st.expander("About the Hardware Unit", expanded=False):
        st.markdown(
            "- **Controller:** an ESP32 microcontroller (Wi-Fi/BLE enabled) reads all four sensor "
            "channels in real time and streams them to this app.\n"
            "- **Knee ROM sensor:** an IMU (inertial measurement unit) strapped at the knee measures "
            "active flexion/extension range of motion, in degrees.\n"
            "- **Gait sensors:** IMUs on the lower limb derive walking cadence (steps/min) and the "
            "left-right gait-cycle asymmetry (%) over a short walking trial.\n"
            "- **Pressure sensors:** insole-mounted force-sensitive resistors under each foot measure "
            "left-right load-bearing (plantar pressure) asymmetry (%).\n"
            "- **Data flow:** the ESP32 is expected to stream these four readings to this app over "
            "serial/BLE/HTTP (wire the live reader into `render_hardware_module()` in "
            "`components/hardware_module.py`); if no device is connected, use Demonstration / Manual "
            "Input Mode below to enter values by hand instead.\n"
            "- **No AI/ML on this pathway:** every reading is compared directly against the fixed, "
            "editable clinical thresholds in `config/thresholds.py` — there is no model to train or "
            "retrain here."
        )

    with st.expander("Precautions Before Screening", expanded=False):
        st.markdown(
            "- Confirm all sensors are **securely attached and correctly calibrated** before starting "
            "a reading — a loose IMU or insole sensor produces unreliable values.\n"
            "- Have the patient walk on a **flat, obstacle-free surface** for the cadence/gait trial.\n"
            "- Avoid **loose clothing or footwear** that could shift or dislodge the pressure sensors "
            "during the walk.\n"
            "- **Re-take a reading** if the device reports a connection drop, battery warning, or a "
            "clearly implausible value (e.g. 0° ROM, 0 steps/min).\n"
            "- These readings are a **screening aid only, not a diagnosis** — treat a Moderate/High "
            "Risk result as a prompt for clinical referral, not a confirmed condition."
        )

    st.caption(
        "Sensor measurements are obtained from the ESP32 + IMU/pressure sensor unit. "
        "If hardware is not currently connected, use Demonstration / Manual Input Mode below."
    )

    demo_mode = st.toggle("Demonstration / Manual Input Mode (no ESP32 connected)", key="hw_demo_mode", value=True)

    if demo_mode:
        demo_ribbon()
        c1, c2 = st.columns(2)
        with c1:
            knee_rom = st.number_input("Knee Range of Motion — ROM (degrees)", min_value=0.0, max_value=180.0, value=125.0, step=1.0, key="hw_rom")
            gait_asym = st.number_input("Gait Asymmetry (%)", min_value=0.0, max_value=100.0, value=4.0, step=0.5, key="hw_gait")
        with c2:
            cadence = st.number_input("Walking Cadence (steps/min)", min_value=0.0, max_value=200.0, value=105.0, step=1.0, key="hw_cadence")
            pressure_asym = st.number_input("Left-Right Pressure Asymmetry (%)", min_value=0.0, max_value=100.0, value=8.0, step=0.5, key="hw_pressure")
    else:
        st.warning(
            "Live ESP32 connection is not configured in this deployment. Connect the "
            "device's data feed in this section of the code (e.g. serial/BLE/HTTP "
            "reader) to populate live readings, or use Demonstration Mode above."
        )
        knee_rom = cadence = gait_asym = pressure_asym = None

    card_close()

    run = st.button("Run Hardware OA Risk Assessment", key="hw_run_btn", use_container_width=True)

    if not run:
        return None

    try:
        sensor = process_sensor_data(knee_rom, cadence, gait_asym, pressure_asym, demo_mode=demo_mode)
    except SensorValidationError as e:
        st.error(f"Error: {e}")
        return None

    result = evaluate_hardware_risk(patient_info, patient_history, sensor)
    _render_hardware_result(result, sensor)

    pdf_bytes = generate_hardware_pdf_report(patient_info, patient_history, sensor, result)
    st.download_button(
        "Download Hardware OA Screening Report (PDF)",
        data=pdf_bytes,
        file_name=f"hardware_oa_report_{patient_info.patient_id}.pdf",
        mime="application/pdf",
        use_container_width=True,
    )

    return {"sensor": sensor, "result": result, "pdf_bytes": pdf_bytes}


def _render_hardware_result(result, sensor):
    card_open("Hardware OA Risk Assessment Result")

    if sensor.demo_mode:
        demo_ribbon("Result generated from manually entered demonstration values")

    risk_banner(result.score, result.category, subtitle="Hardware OA Risk Score / Screening Category (rule-based, not a clinical probability)")

    st.markdown("#### Sensor Measurements")
    m1, m2, m3, m4 = st.columns(4)
    with m1:
        metric_card(f"{sensor.knee_rom_degrees:.1f}°", "Knee ROM")
    with m2:
        metric_card(f"{sensor.walking_cadence_spm:.1f}", "Cadence (spm)")
    with m3:
        metric_card(f"{sensor.gait_asymmetry_percent:.1f}%", "Gait Asymmetry")
    with m4:
        metric_card(f"{sensor.pressure_asymmetry_percent:.1f}%", "Pressure Asymmetry")

    st.markdown("#### Detected Risk Markers &amp; Explanation")
    rows_html = "<table><tr><th>Factor</th><th>Status</th><th>Detail</th></tr>"
    for m in result.markers:
        rows_html += f"<tr><td>{m.factor}</td><td>{status_badge(m.status)}</td><td>{m.detail}</td></tr>"
    rows_html += "</table>"
    st.markdown(rows_html, unsafe_allow_html=True)

    card_close()
