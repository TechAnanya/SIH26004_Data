"""
Streamlit component: AI Posture Detection pathway.

Uses Google's MediaPipe Pose model (the AI component of this pathway) to
locate hip/knee/ankle landmarks from an uploaded lower-limb photo; the
Hip-Knee-Ankle alignment angle is then compared against fixed threshold
values (rule-based, see config/thresholds.py) -- see
utils/posture_analysis.py for the actual logic. This is a third,
independent pathway alongside Hardware and Software: its result and
report are never combined with either of the other two.
"""

import cv2
import numpy as np
import streamlit as st
from PIL import Image

from config import settings, thresholds as th
from utils.posture_analysis import analyze_posture_image, mediapipe_available
from utils.pdf_report import generate_posture_pdf_report
from utils.ui_helpers import card_open, card_close, metric_card, risk_banner


def _resize_for_processing(pil_image: Image.Image, max_dimension: int) -> Image.Image:
    """
    Downscale (never upscale) a photo so its longest side is at most
    `max_dimension` pixels, preserving aspect ratio. Keeps the annotated
    overlay, the in-app preview, and the PDF report's embedded image a
    reasonable size for large phone-camera photos, without affecting the
    HKA angle result (a ratio of landmark positions, not an absolute-pixel
    measurement).
    """
    width, height = pil_image.size
    longest = max(width, height)
    if longest <= max_dimension:
        return pil_image
    scale = max_dimension / float(longest)
    new_size = (max(1, int(width * scale)), max(1, int(height * scale)))
    return pil_image.resize(new_size, Image.LANCZOS)


def render_posture_module(patient_info, patient_history):
    card_open("AI Posture Detection — Lower Limb Alignment")

    available, err = mediapipe_available()
    if not available:
        st.error(
            "The 'mediapipe' package is not installed in this environment. "
            "Install it with `pip install mediapipe` to use AI Posture Detection."
        )
        st.caption(f"Details: {err}")
        card_close()
        return None

    st.caption(
        "Upload a frontal lower-limb photo. Google's MediaPipe pose-estimation "
        "model (AI) detects hip/knee/ankle landmarks; the Hip-Knee-Ankle (HKA) "
        "alignment angle is then compared against fixed clinical thresholds "
        "(rule-based, calibratable in config/thresholds.py) to flag varus/valgus "
        "deviation and left-right asymmetry. Keep the hip crease visible — "
        "avoid clothing or hands covering the waistband."
    )

    with st.expander("Precautions Before Screening", expanded=False):
        st.markdown(
            "- Stand upright, facing the camera, with **both legs fully visible** from hip to ankle.\n"
            "- Wear **fitted clothing** — loose or baggy clothing over the hip/knee can hide landmarks "
            "and skew the measured angle.\n"
            "- Use **even, adequate lighting** and a plain, uncluttered background.\n"
            "- Keep the camera **level and roughly waist-height**, a few steps back so the full lower "
            "body fits in frame.\n"
            "- Avoid a partially obstructed pose (hands on hips, sitting, one leg behind the other).\n"
            "- This is a **screening aid based on a single static photo**, not a formal gait or "
            "biomechanical assessment — treat any flagged result as a prompt for clinical follow-up, "
            "not a diagnosis."
        )

    uploaded_file = st.file_uploader(
        "Upload lower limb photo", type=["jpg", "jpeg", "png"], key="posture_upload"
    )

    card_close()

    if uploaded_file is None:
        st.info("Upload an image to begin analysis.")
        return None

    pil_image = Image.open(uploaded_file).convert("RGB")
    pil_image = _resize_for_processing(pil_image, settings.POSTURE_MAX_IMAGE_DIMENSION)
    image_bgr = cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)

    with st.spinner("Detecting pose landmarks..."):
        result = analyze_posture_image(image_bgr)

    if not result.success:
        st.error(f"{result.error}")
        if result.annotated_image_rgb is not None:
            st.image(result.annotated_image_rgb, caption="Original Image", width=settings.POSTURE_DISPLAY_WIDTH)
        return None

    _render_posture_result(result)

    pdf_bytes = generate_posture_pdf_report(patient_info, patient_history, result)
    st.download_button(
        "Download AI Posture Detection Report (PDF)",
        data=pdf_bytes,
        file_name=f"posture_oa_report_{patient_info.patient_id}.pdf",
        mime="application/pdf",
        use_container_width=True,
    )

    return {"result": result, "pdf_bytes": pdf_bytes}


def _render_posture_result(result):
    card_open("AI Posture Detection Result")

    if result.low_confidence:
        st.warning(
            "Some joint points (likely hip) had lower detection confidence — "
            "angles may be less precise. For best accuracy, use a photo with "
            "the hip clearly visible, not covered by clothing or hands."
        )

    st.image(result.annotated_image_rgb, caption="Annotated Posture Analysis", width=settings.POSTURE_DISPLAY_WIDTH)

    category = "High Risk" if result.overall_risk else "Low Risk"
    risk_banner(
        None,
        category,
        subtitle="Posture-based alignment assessment (AI landmark detection + rule-based thresholds, not a clinical probability)",
    )

    st.markdown("#### Measured Values")
    m1, m2, m3 = st.columns(3)
    with m1:
        metric_card(f"{result.knee_angle_right}°", "Right Knee Angle (HKA)")
    with m2:
        metric_card(f"{result.knee_angle_left}°", "Left Knee Angle (HKA)")
    with m3:
        metric_card(f"{result.angle_asymmetry}°", "Angle Asymmetry")

    low = th.POSTURE_KNEE_ANGLE_THRESHOLDS["normal_min_degrees"]
    high = th.POSTURE_KNEE_ANGLE_THRESHOLDS["normal_max_degrees"]
    st.caption(
        f"Normal range: {low}° – {high}°  |  Asymmetry threshold: {th.POSTURE_ASYMMETRY_MAX_DEGREES}°"
    )

    def risk_label(flag):
        return "Abnormal / At Risk" if flag else "Normal"

    st.write(f"**Right Knee:** {risk_label(result.risk_flag_right)} — {result.classification_right}")
    st.write(f"**Left Knee:** {risk_label(result.risk_flag_left)} — {result.classification_left}")
    st.write(f"**Symmetry:** {risk_label(result.risk_flag_asymmetry)}")

    with st.expander("Keypoint Legend"):
        for idx, name in [
            (11, "Left Hip"), (12, "Right Hip"),
            (13, "Left Knee"), (14, "Right Knee"),
            (15, "Left Ankle"), (16, "Right Ankle"),
        ]:
            st.write(f"**{idx}** — {name}")

    card_close()
