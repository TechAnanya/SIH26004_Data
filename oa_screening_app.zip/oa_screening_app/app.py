"""
SandhiSetu -- Integrated AI Platform for Knee Osteoarthritis Screening
Main Streamlit application entry point.

Workflow: Basic Information -> Patient History -> Screening Method ->
Selected Screening (Hardware OR Software) -> Result -> Generate Report.

Run with:  streamlit run app.py
"""

import streamlit as st
from datetime import datetime

from config import settings, thresholds
from utils.ui_helpers import (
    inject_css, top_bar, card_open, card_close, step_indicator,
    disclaimer_block, metric_card, problem_statement_card,
)
from components.patient_form import (
    render_patient_info_form,
    render_patient_history_form,
    build_patient_info_object,
    build_patient_history_object,
)
from components.hardware_module import render_hardware_module
from components.software_module import render_software_module
from components.posture_module import render_posture_module

st.set_page_config(page_title=settings.APP_NAME, layout="wide")
inject_css()

# ----------------------------------------------------------------------
# Session state initialization
# ----------------------------------------------------------------------
if "nav" not in st.session_state:
    st.session_state.nav = "New Screening"
if "wf_step" not in st.session_state:
    st.session_state.wf_step = 0  # 0=Basic Info, 1=History, 2=Method, 3=Screening/Result
if "patient_info_obj" not in st.session_state:
    st.session_state.patient_info_obj = None
if "patient_history_obj" not in st.session_state:
    st.session_state.patient_history_obj = None
if "screening_method" not in st.session_state:
    st.session_state.screening_method = None
if "screening_history" not in st.session_state:
    st.session_state.screening_history = []  # list of dict summaries

WORKFLOW_STEPS = ["Basic Info", "Patient History", "Screening Method", "Result"]


def go_to_step(n):
    st.session_state.wf_step = n


def reset_workflow():
    st.session_state.wf_step = 0
    st.session_state.patient_info_obj = None
    st.session_state.patient_history_obj = None
    st.session_state.screening_method = None


def log_screening(method, category_or_assessment, extra=""):
    st.session_state.screening_history.append({
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "patient_id": st.session_state.patient_info_obj.patient_id if st.session_state.patient_info_obj else "-",
        "patient_name": st.session_state.patient_info_obj.patient_name if st.session_state.patient_info_obj else "-",
        "method": method,
        "result": category_or_assessment,
        "detail": extra,
    })


# ----------------------------------------------------------------------
# Sidebar navigation
# ----------------------------------------------------------------------
with st.sidebar:
    st.markdown(f"## {settings.APP_NAME}")
    st.caption(settings.APP_TAGLINE)
    st.markdown("---")
    nav = st.radio(
        "Navigation",
        ["Dashboard", "New Screening", "Screening History", "Reports", "Settings"],
        index=["Dashboard", "New Screening", "Screening History", "Reports", "Settings"].index(st.session_state.nav),
        label_visibility="collapsed",
    )
    st.session_state.nav = nav
    st.markdown("---")
    st.caption(f"Organization: {settings.ORG_NAME}")
    st.caption(f"Team {settings.TEAM_NAME} — SIH PS# {settings.SIH_PS_NUMBER}")
    st.caption("Preliminary screening tool — not a diagnostic device.")


# ----------------------------------------------------------------------
# Dashboard
# ----------------------------------------------------------------------
def page_dashboard():
    top_bar("Dashboard")
    problem_statement_card()
    history = st.session_state.screening_history

    c1, c2, c3, c4, c5 = st.columns(5)
    with c1:
        metric_card(str(len(history)), "Total Screenings (this session)")
    with c2:
        hw_count = sum(1 for h in history if h["method"] == "Hardware")
        metric_card(str(hw_count), "Hardware Screenings")
    with c3:
        sw_count = sum(1 for h in history if h["method"] == "Software")
        metric_card(str(sw_count), "Software Screenings")
    with c4:
        posture_count = sum(1 for h in history if h["method"] == "Posture")
        metric_card(str(posture_count), "Posture Screenings")
    with c5:
        high_risk = sum(1 for h in history if "High" in str(h["result"]) or "ABNORMAL" in str(h["result"]))
        metric_card(str(high_risk), "High Risk / Abnormal Flags")

    st.write("")
    card_open("Recent Screenings")
    if not history:
        st.info("No screenings recorded yet in this session. Start a New Screening from the sidebar.")
    else:
        st.dataframe(
            history[::-1],
            use_container_width=True,
            hide_index=True,
        )
    card_close()

    card_open("Quick Start")
    st.write(
        "1. Go to **New Screening** in the sidebar.\n"
        "2. Enter basic patient information (BMI is auto-calculated).\n"
        "3. Complete the patient history / symptom screening.\n"
        "4. Choose **Hardware OA Risk Marker** or **Software OA Risk Marker**.\n"
        "5. Review the result and download the PDF report."
    )
    card_close()
    disclaimer_block()


# ----------------------------------------------------------------------
# New Screening workflow
# ----------------------------------------------------------------------
def page_new_screening():
    top_bar("New Screening")
    step_indicator(WORKFLOW_STEPS, st.session_state.wf_step)

    step = st.session_state.wf_step

    if step == 0:
        data = render_patient_info_form()
        col1, col2 = st.columns([1, 5])
        with col1:
            if st.button("Next", key="next_basic", use_container_width=True):
                info, errors = build_patient_info_object(data)
                if errors:
                    for e in errors:
                        st.error(e)
                else:
                    st.session_state.patient_info_obj = info
                    go_to_step(1)
                    st.rerun()

    elif step == 1:
        data = render_patient_history_form()
        col1, col2, col3 = st.columns([1, 1, 4])
        with col1:
            if st.button("Back", key="back_history", use_container_width=True):
                go_to_step(0)
                st.rerun()
        with col2:
            if st.button("Next", key="next_history", use_container_width=True):
                history, errors = build_patient_history_object(data)
                if errors:
                    for e in errors:
                        st.error(e)
                else:
                    st.session_state.patient_history_obj = history
                    go_to_step(2)
                    st.rerun()

    elif step == 2:
        card_open("Screening Method")
        st.write("Select exactly one screening pathway. All three pathways are fully independent and generate separate reports.")
        c1, c2, c3 = st.columns(3)
        with c1:
            st.markdown(
                '<div class="oa-method-card"><h4>Hardware OA Risk Marker</h4>'
                '<div class="oa-method-caption">Rule/threshold-based assessment using ESP32 sensor '
                'measurements. No AI/ML.</div></div>',
                unsafe_allow_html=True,
            )
            if st.button("Select Hardware OA Risk Marker", key="select_hw", use_container_width=True):
                st.session_state.screening_method = "Hardware"
                go_to_step(3)
                st.rerun()
        with c2:
            st.markdown(
                '<div class="oa-method-card"><h4>Software OA Risk Marker</h4>'
                '<div class="oa-method-caption">Deep-learning analysis of a knee X-ray using the '
                'trained G5 model.</div></div>',
                unsafe_allow_html=True,
            )
            if st.button("Select Software OA Risk Marker", key="select_sw", use_container_width=True):
                st.session_state.screening_method = "Software"
                go_to_step(3)
                st.rerun()
        with c3:
            st.markdown(
                '<div class="oa-method-card"><h4>AI Posture Detection</h4>'
                '<div class="oa-method-caption">AI pose-landmark detection (MediaPipe) on a '
                'lower-limb photo, with rule-based alignment thresholds.</div></div>',
                unsafe_allow_html=True,
            )
            if st.button("Select AI Posture Detection", key="select_posture", use_container_width=True):
                st.session_state.screening_method = "Posture"
                go_to_step(3)
                st.rerun()
        card_close()

        if st.button("Back", key="back_method"):
            go_to_step(1)
            st.rerun()

    elif step == 3:
        info = st.session_state.patient_info_obj
        history = st.session_state.patient_history_obj
        method = st.session_state.screening_method

        if info is None or history is None or method is None:
            st.warning("Please complete the previous steps first.")
            if st.button("Start Over"):
                reset_workflow()
                st.rerun()
            return

        if st.button("Back to Screening Method", key="back_result"):
            go_to_step(2)
            st.rerun()

        if method == "Hardware":
            outcome = render_hardware_module(info, history)
            if outcome:
                log_screening("Hardware", outcome["result"].category, f"Score {outcome['result'].score}")
        elif method == "Software":
            outcome = render_software_module(info, history)
            if outcome and outcome["prediction"].success:
                log_screening("Software", outcome["prediction"].assessment,
                               f"{outcome['prediction'].positive_class_probability * 100:.1f}% probability")
        else:
            outcome = render_posture_module(info, history)
            if outcome:
                log_screening(
                    "Posture",
                    "High Risk" if outcome["result"].overall_risk else "Low Risk",
                    f"Asymmetry {outcome['result'].angle_asymmetry}°",
                )

        st.write("")
        if st.button("Start a New Screening", key="restart"):
            reset_workflow()
            st.rerun()


# ----------------------------------------------------------------------
# Screening History
# ----------------------------------------------------------------------
def page_history():
    top_bar("Screening History")
    card_open("Session Screening Log")
    history = st.session_state.screening_history
    if not history:
        st.info("No screenings have been recorded yet in this session.")
    else:
        st.dataframe(history[::-1], use_container_width=True, hide_index=True)
    card_close()
    st.caption(
        "This log is kept for the current session only. For persistent, multi-user "
        "records, connect the application to a database or electronic health record system."
    )


# ----------------------------------------------------------------------
# Reports
# ----------------------------------------------------------------------
def page_reports():
    top_bar("Reports")
    card_open("Generated Reports")
    st.write(
        "PDF reports are generated at the end of each Hardware or Software screening "
        "and can be downloaded immediately from the **Result** step of **New Screening**."
    )
    st.write(
        "Each report is independently generated for its pathway and includes patient "
        "information, history, the screening result, an explanation of contributing "
        "factors, follow-up guidance, and the medical disclaimer."
    )
    card_close()


# ----------------------------------------------------------------------
# Settings
# ----------------------------------------------------------------------
def page_settings():
    top_bar("Settings")

    card_open("G5 Model Configuration")
    st.write(f"**Model path:** `{settings.G5_MODEL_PATH}`")
    st.write(f"**Backend:** `{settings.G5_MODEL_BACKEND}`")
    st.write(f"**Input size:** {settings.G5_INPUT_SIZE}")
    st.write(f"**Preprocessing mode:** `{settings.G5_PREPROCESS_MODE}`")
    st.write(f"**Class labels:** {settings.G5_CLASS_LABELS}")
    st.write(f"**Grad-CAM/Score-CAM base layer (nested backbone):** `{settings.G5_GRADCAM_BASE_LAYER_NAME or '(none / flat model)'}`")
    st.write(f"**Grad-CAM/Score-CAM target conv layer:** `{settings.G5_GRADCAM_TARGET_LAYER or '(not set)'}`")
    st.write(f"**Score-CAM channels:** {settings.G5_SCORECAM_MAX_CHANNELS}")
    st.write(f"**LIME samples / features:** {settings.G5_LIME_NUM_SAMPLES} / {settings.G5_LIME_NUM_FEATURES}")
    st.caption(
        "These are pre-filled to match the EfficientNetB0-based Keras model "
        "(final_model.h5). Update via environment variables (or config/settings.py) "
        "if you retrain with a different architecture, class order, or preprocessing."
    )
    card_close()

    card_open("Hardware Rule/Threshold Configuration")
    st.write("Knee ROM (degrees):", thresholds.KNEE_ROM_THRESHOLDS)
    st.write("Walking Cadence (steps/min):", thresholds.WALKING_CADENCE_THRESHOLDS)
    st.write("Gait Asymmetry (%):", thresholds.GAIT_ASYMMETRY_THRESHOLDS)
    st.write("Pressure Asymmetry (%):", thresholds.PRESSURE_ASYMMETRY_THRESHOLDS)
    st.write("Risk score category cut-offs:", thresholds.RISK_CATEGORY_THRESHOLDS)
    st.caption(
        "These are plain configurable reference values (no ML). Update "
        "config/thresholds.py as better-validated clinical/research evidence "
        "becomes available for your target population."
    )
    card_close()

    card_open("AI Posture Detection Thresholds")
    st.write("HKA angle normal range (degrees):", thresholds.POSTURE_KNEE_ANGLE_THRESHOLDS)
    st.write("Asymmetry threshold (degrees):", thresholds.POSTURE_ASYMMETRY_MAX_DEGREES)
    st.write("Landmark visibility (overlay / angle calc):",
             thresholds.POSTURE_LEG_VISIBILITY_THRESHOLD, "/", thresholds.POSTURE_CORE_JOINT_MIN_VISIBILITY)
    st.caption(
        "Landmark detection (MediaPipe) is the only AI component of this pathway; "
        "the alignment interpretation above is a plain threshold comparison, "
        "just like the Hardware pathway's rule engine."
    )
    card_close()

    card_open("Organization")
    st.write(f"**Organization name:** {settings.ORG_NAME}")
    st.caption("Set the OA_SCREEN_ORG_NAME environment variable to change the name shown on reports.")
    card_close()


# ----------------------------------------------------------------------
# Router
# ----------------------------------------------------------------------
PAGES = {
    "Dashboard": page_dashboard,
    "New Screening": page_new_screening,
    "Screening History": page_history,
    "Reports": page_reports,
    "Settings": page_settings,
}

PAGES[st.session_state.nav]()
